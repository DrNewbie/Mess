if LocalC4BombBase then
	LocalC4BombBase.KaBoom()
end