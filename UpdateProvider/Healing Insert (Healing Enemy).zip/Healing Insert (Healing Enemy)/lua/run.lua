if managers.player and managers.player:player_unit() and managers.player:player_unit():movement() and managers.player:player_unit():movement()._states.standard and managers.player:player_unit():movement()._states.standard.Run_Healing_Insert_Melee then
	managers.player:player_unit():movement()._states.standard:Run_Healing_Insert_Melee()
end