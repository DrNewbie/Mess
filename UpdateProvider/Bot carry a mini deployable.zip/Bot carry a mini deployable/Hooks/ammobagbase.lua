function AmmoBagBase:set_min()
	self._max_ammo_amount = 2
	self._ammo_amount = 2
	self:_set_visual_stage()
end