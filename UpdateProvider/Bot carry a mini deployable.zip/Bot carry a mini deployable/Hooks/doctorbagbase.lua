function DoctorBagBase:set_min()
	self._max_amount = 1
	self._amount = 1
	self:_set_visual_stage()
end