if managers.player and managers.player:player_unit() and managers.player:player_unit():movement() and managers.player:player_unit():movement()._states.standard then
	managers.player:player_unit():movement()._states.standard:Ask_Bot_Use_Min_Equipment()
end