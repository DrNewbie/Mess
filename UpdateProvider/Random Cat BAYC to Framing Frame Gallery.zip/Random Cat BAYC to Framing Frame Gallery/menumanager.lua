if RndNFTsBAYC2FF then
	return
end

_G.RndNFTsBAYC2FF = {}

RndNFTsBAYC2FF.ModPath = RndNFTsBAYC2FF.ModPath or ModPath

RndNFTsBAYC2FF.PaintingPaths = {
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_7_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_annabelle_8_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_annabelle_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_7_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_8_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_9_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_10_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_11_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_12_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_13_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_14_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_15_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ben_qwek_16_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ben_qwek_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ben_qwek_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ben_qwek_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ben_qwek_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_7_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_8_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_9_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_10_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_small_ben_qwek_11_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_darius_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_darius_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_darius_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_darius_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_darius_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_darius_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_7_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_8_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_9_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_10_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_11_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_12_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_darius_13_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_7_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_8_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_9_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_10_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_large_ray_11_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_1_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_2_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_3_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_4_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_5_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_6_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_7_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_8_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_9_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_10_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_11_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_12_df",
	"units/payday2/props/shared_textures/com_int_gallery_wall_painting_medium_ray_13_df"
}

function RndNFTsBAYC2FF:Reload(is_load)
	for id, painting in pairs(self.PaintingPaths) do
		BLTAssetManager:CreateEntry( 
			Idstring(painting), 
			Idstring("texture"), 
			self.ModPath..'cache/'..painting..'.texture',
			nil 
		)
	end
	if is_load then
		QuickMenu:new(
			"[DownloadMoreBAYC]",
			"Complete",
			{
				{
					text = "OK",
					is_cancel_button = true
				}
			}
		):Show()
	end
end

function RndNFTsBAYC2FF:RunInitNow()
	if DelayedCalls and dohttpreq then
		local NFTsIDBool = {}
		os.execute('mkdir "'..self.ModPath..'cache/"')
		os.execute('mkdir "'..self.ModPath..'cache/units/payday2/props/shared_textures/"')
		for id, painting in pairs(self.PaintingPaths) do
			if false then
				math.randomseed()
				math.randomseed()
				math.randomseed()
			else
				DelayedCalls:Add("D_"..Idstring('RndNFTsBAYC2FF::'..painting):key(), 1.5 * id, function()
					local NFTsID = math.random(1, 9999)
					while NFTsIDBool[NFTsID] do
						NFTsID = math.random(1, 9999)
					end
					local uurl = "https://nonfungible.com/_next/image?url=http%3A%2F%2F10.0.1.12%3A3000%2Fapi%2Fv4%2Fasset%2Fmedia%2Fimage%2Fboredapeclub%2FBAYC%2F"..NFTsID.."&w=1920&q=75"
					NFTsIDBool[NFTsID] = true
					dohttpreq(uurl, 
						function(cache)
							local basepath = Application:base_path()
							basepath = basepath:gsub('\\PAYDAY 2\\', '\\PAYDAY 2')
							local img2dds = self.ModPath..'tool/'
							img2dds = Application:nice_path(img2dds, true) .. "img2dds.exe"
							local webppath = self.ModPath..'cache/'..painting..'.webp'
							local ddspath = self.ModPath..'cache/'..painting..'.texture'
							local ppic = io.open(webppath, 'wb+')
							if ppic then						
								ppic:write(cache)
								ppic:close()
								webppath = Application:nice_path(basepath .. "/" .. webppath, false)											
								ddspath = Application:nice_path(basepath .. "/" .. ddspath, false)
								local __cmd = tostring(
									string.format('%s -c "%s" "%s" & del "%s"', img2dds, webppath, ddspath, webppath)
								)
								os.execute(__cmd)
								if id >= #(self.PaintingPaths) then
									DelayedCalls:Add("D_"..Idstring('RndNFTsBAYC2FF::Reload'):key(), 10, function()
										RndNFTsBAYC2FF:Reload(true)
									end)
								end
							end
						end
					)
				end)
			end
		end
	end
end

RndNFTsBAYC2FF:Reload()

Hooks:Add("LocalizationManagerPostInit", "RndNFTsBAYC2FF_loc", function(loc)
	loc:load_localization_file(RndNFTsBAYC2FF.ModPath.."loc/English.txt")
end)

Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_RndNFTsBAYC2FF", function(menu_manager, nodes)
	MenuHelper:NewMenu("RndNFTsBAYC2FFMenuID")
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_RndNFTsBAYC2FF", function(menu_manager, nodes)
	MenuCallbackHandler.CleanAllRndNFTsBAYC2FFNow = function()
		RndNFTsBAYC2FF:RunInitNow()
		QuickMenu:new(
			"[DownloadMoreBAYC]",
			"Nowloading",
			{
				{
					text = "OK",
					is_cancel_button = true
				}
			}
		):Show()
	end
	MenuHelper:AddButton({
		id = "CleanAllRndNFTsBAYC2FFNow",
		title = "menu_CleanAllRndNFTsBAYC2FFNow_name",
		desc = "menu_CleanAllRndNFTsBAYC2FFNow_desc",
		callback = "CleanAllRndNFTsBAYC2FFNow",
		menu_id = "RndNFTsBAYC2FFMenuID",
	})
end)

Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_RndNFTsBAYC2FF", function(menu_manager, nodes)
	nodes["RndNFTsBAYC2FFMenuID"] = MenuHelper:BuildMenu("RndNFTsBAYC2FFMenuID")
	MenuHelper:AddMenuItem(nodes["blt_options"], "RndNFTsBAYC2FFMenuID", "menu_CleanAllRndNFTsBAYC2FFNow_name", "menu_CleanAllRndNFTsBAYC2FFNow_desc")
end)