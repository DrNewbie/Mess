if managers.player and managers.player.SwitchThrowables then
	managers.player:SwitchThrowables()
end