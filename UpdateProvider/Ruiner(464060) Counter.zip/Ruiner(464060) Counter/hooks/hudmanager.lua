local ThisModPath = ModPath
local ThisModAssets = ThisModPath.."97668a8af5693282/assets/"
local ThisModIds = Idstring(ThisModPath):key()
local __Name = function(__id)
	return "R4C_"..Idstring(tostring(__id).."::"..ThisModIds):key()
end
if RequiredScript == "lib/managers/playermanager" then
	local __dt2 = __Name("__dt2")
	local __nt1 = __Name("__nt1")
	local __dt_stop = __Name("__nt1")
	local __combo1 = __Name("__combo1")
	local __combo_dt = 6
	Hooks:PostHook(PlayerManager, "update", __Name("PlayerManager:update"), function(self, __t)
		if not self[__dt_stop] then
			self[__dt2] = self[__dt2] or {}
			self[__nt1] = __t
			self[__combo1] = self[__combo1] or 0
			local __combo = 0
			for __i, __d in pairs(self[__dt2]) do
				if __d then
					if __d < __t then
						self[__dt2][__i] = nil
					else
						__combo = __combo + 1
					end
				else
					self[__dt2][__i] = nil
				end
			end
			if self[__combo1] ~= __combo then
				if not self[__dt_stop] and __combo >= self[__combo1] and __combo > 0 then
					managers.hud:____run_97668a8af5693282_function(math.round(__combo/3)*3)
				end
				self[__combo1] = __combo
			end
		else
			self[__dt_stop] = false
		end
	end)	
	Hooks:PostHook(PlayerManager, "on_killshot", __Name("PlayerManager:on_killshot"), function(self, killed_unit, variant, headshot, weapon_id)
		local player_unit = self:player_unit()
		if player_unit then
			if not CopDamage.is_civilian(killed_unit:base()._tweak_table) then
				self[__dt_stop] = true
				self[__dt2][__Name(killed_unit)] = self[__nt1] + __combo_dt or 0
			end
		end
	end)	
elseif RequiredScript == "lib/managers/hudmanager" then
	local __idx = __Name("__idx")
	local __xnum = __Name("__xnum")
	local __dt1 = __Name("__dt1")
	local __enable = __Name("__enable")
	local __name1 = __Name("__name1")
	local __panel1 = __Name("__panel1")
	local __bitmap1 = __Name("__bitmap1")
	local __texture_size = {1920, 336}
	local __scale = 1
	local __id_fix = function(__id)
		if type(__id) == "number" then
			if __id >= 0 and __id <= 9 then
				return "P_00"..__id
			elseif __id >= 10 and __id <= 99 then
				return "P_0"..__id
			elseif __id >= 100 and __id <= 999 then
				return "P_"..__id
			end
		end
		return nil
	end
	local __png_range = {
		[3] = {1, 44},
		[6] = {1, 61},
		[9] = {1, 60},
		[12] = {1, 61},
		[15] = {1, 60}
	}
	local __get_png = function(__type, __id)
		if type(__type) == "number" and type(__id) == "number" then
			if __png_range[__type] and __png_range[__type][1] <= __id and __id <= __png_range[__type][2] and __id_fix(__id) then
				return '97668a8af5693282/____x'..__type..'/'..__id_fix(__id)
			end
		end
		return nil
	end
	Hooks:PostHook(HUDManager, "_player_hud_layout", __Name("_player_hud_layout"), function(self)
		local p_load = "packages/97668a8af5693282"
		if PackageManager:package_exists(p_load) then
			if PackageManager:loaded(p_load) then
				PackageManager:unload(p_load)
			end
			PackageManager:load(p_load)
		end	
		local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
		self[__panel1] = self[__panel1] or hud and hud.panel or self._ws:panel({name = __name1})
		__scale = self[__panel1]:w() / __texture_size[1]
		self[__panel1]:set_size(__texture_size[1], __texture_size[2])
		self[__bitmap1] = self[__panel1]:bitmap({
			texture = __get_png(3, 1),
			color = Color.white:with_alpha(1),
			align = "right",
			visible = false,
			layer = 1
		})
		self[__bitmap1]:set_size(self[__bitmap1]:w()*__scale, self[__bitmap1]:h()*__scale)
		self[__idx] = 1
		self[__xnum] = 0
		self[__enable] = false
		self[__dt1] = false
	end)
	Hooks:PostHook(HUDManager, "update", __Name("HUDManager:update"), function(self, __t, __dt)
		if self[__panel1] and self[__bitmap1] and self[__dt1] then
			if self[__enable] and __get_png(self[__xnum], self[__idx]) then
				self[__bitmap1]:set_image(__get_png(self[__xnum], self[__idx]))
				self[__idx] = self[__idx] + 1
			else
				self[__bitmap1]:set_visible(false)
				self[__enable] = false
				self[__idx] = 1
			end
			self[__dt1] = false
		else
			self[__dt1] = true
		end
	end)
	function HUDManager:____run_97668a8af5693282_function(v_xnum)
		if self[__panel1] and self[__bitmap1] then
			self[__idx] = 1
			self[__xnum] = v_xnum or 3
			if __get_png(self[__xnum], self[__idx]) then
				self[__bitmap1]:set_image(__get_png(self[__xnum], self[__idx]))
				self[__bitmap1]:set_visible(true)
				self[__enable] = true
			end
		end
	end
end