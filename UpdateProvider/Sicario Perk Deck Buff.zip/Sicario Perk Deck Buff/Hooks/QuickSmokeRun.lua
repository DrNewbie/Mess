if managers.player and managers.player:player_unit() and managers.player:__is_smoke_screen_grenade() then
	managers.player:QuickSmokeRun()
end