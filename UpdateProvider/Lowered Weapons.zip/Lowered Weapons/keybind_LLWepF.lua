if _G.__LLWepF_Forced_to_Run then
	_G.__LLWepF_Forced_to_RunEnd_ReTry = 0.5
else
	_G.__LLWepF_Forced_to_RunStart_ReTry = 0.5
end