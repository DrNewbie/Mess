if _G.__LLWepF_Forced_to_Run then
	_G.__LLWepF_Forced_to_Run = false
	_G.__LLWepF_ForcedApplyToFov = true
else
	_G.__LLWepF_Forced_to_Run = true
end