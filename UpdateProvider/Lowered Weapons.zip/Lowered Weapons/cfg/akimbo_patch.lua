table.insert(LLWepF.AddonCfg, {
	categories = {"akimbo"},
	__offset_pos_x = 0,
	__offset_pos_y = 0,
	__offset_pos_z = -66,
	__offset_rot_x = 0,
	__offset_rot_y = 66,
	__offset_rot_z = 0
})