table.insert(LLWepF.AddonCfg, {
	categories = "pistol",
	__offset_pos_x = 10,
	__offset_pos_y = 0,
	__offset_pos_z = -30,
	__offset_rot_x = 0,
	__offset_rot_y = 70,
	__offset_rot_z = 0
})