_G.SpecialUnitFunction = _G.SpecialUnitFunction or {}

SpecialUnitFunction.options_menu = "SpecialUnitFunction_menu"
SpecialUnitFunction.ModPath = ModPath
SpecialUnitFunction.SaveFile = SpecialUnitFunction.SaveFile or SavePath .. "SpecialUnitFunction.txt"
SpecialUnitFunction.settings = {
	fov_camer = {cam_rot_x = 60, cam_rot_y = -60, cam_rot_z = 0, x = 0, y = 0, z = 100}
}
SpecialUnitFunction._unit_name = Idstring("units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3")

function SpecialUnitFunction:Reset()
	self.settings = {
		fov_camer = {cam_rot_x = 60, cam_rot_y = -60, cam_rot_z = 0, x = 0, y = 0, z = 100}
	}
	self:Save()
end

function SpecialUnitFunction:Load()
	local file = io.open(self.SaveFile, "r")
	if file then
		for key, value in pairs(json.decode(file:read("*all"))) do
			self.settings[key] = value
		end
		file:close()
	else
		self:Reset()
	end
end

function SpecialUnitFunction:Save()
	local file = io.open(self.SaveFile, "w+")
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
	if Utils:IsInHeist() and SpecialUnitFunction.CAMERA then
		local cam_rot_x, cam_rot_y, cam_rot_z, x, y, z = 0, -60, 60, 0, 0, 100
		if SpecialUnitFunction and SpecialUnitFunction.settings and SpecialUnitFunction.settings.fov_camer then
			local fov_camer = SpecialUnitFunction.settings.fov_camer
			cam_rot_x, cam_rot_y, cam_rot_z, x, y, z = fov_camer.cam_rot_x, fov_camer.cam_rot_y, fov_camer.cam_rot_z , fov_camer.x, fov_camer.y, fov_camer.z
		end
		local cam_rot = SpecialUnitFunction.CAMERA._camera_object:rotation()
		if cam_rot then
			SpecialUnitFunction.CAMERA._tp_camera_object:set_position(SpecialUnitFunction.CAMERA._camera_object:position() + (cam_rot:x() * cam_rot_x) + (cam_rot:y() * cam_rot_y) + (cam_rot:z() * cam_rot_z) + Vector3(x, y, z))
			SpecialUnitFunction.CAMERA._vp:set_camera(SpecialUnitFunction.CAMERA._tp_camera_object)
		end
	end
end

SpecialUnitFunction:Load()

Hooks:Add("LocalizationManagerPostInit", "SpecialUnitFunction_loc", function(loc)
	LocalizationManager:add_localized_strings({
		["SpecialUnitFunction_menu_title"] = "Bulldozer Simulator",
		["SpecialUnitFunction_menu_desc"] = "",
		["SpecialUnitFunction_fov_camer_cam_rot_x_menu_title"] = "cam_rot_x",
		["SpecialUnitFunction_fov_camer_cam_rot_y_menu_title"] = "cam_rot_y",
		["SpecialUnitFunction_fov_camer_cam_rot_z_menu_title"] = "cam_rot_z",
		["SpecialUnitFunction_fov_camer_x_menu_title"] = "x",
		["SpecialUnitFunction_fov_camer_y_menu_title"] = "y",
		["SpecialUnitFunction_fov_camer_z_menu_title"] = "z",
		["SpecialUnitFunction_Reset_menu_title"] = "Reset",
	})
end)

function SpecialUnitFunction:Warning()
	local _dialog_data = {
		title = "Bot Carry MOD",
		text = managers.localization:text("SpecialUnitFunction_menu_warning4reboot"),
		button_list = {{ text = managers.localization:text("SpecialUnitFunction_menu_use4ok"), is_cancel_button = true }},
		id = tostring(math.random(0,0xFFFFFFFF))
	}
	managers.system_menu:show(_dialog_data)
end

Hooks:Add("MenuManagerSetupCustomMenus", "SpecialUnitFunctionOptions", function( menu_manager, nodes )
	MenuHelper:NewMenu( SpecialUnitFunction.options_menu )
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "SpecialUnitFunctionOptions", function( menu_manager, nodes )
	MenuCallbackHandler.SpecialUnitFunction_Reset_menu_callback = function(self, item)
		SpecialUnitFunction:Reset()
	end
	MenuHelper:AddButton({
		id = "SpecialUnitFunction_Reset_menu_callback",
		title = "SpecialUnitFunction_Reset_menu_title",
		callback = "SpecialUnitFunction_Reset_menu_callback",
		menu_id = SpecialUnitFunction.options_menu,
	})
	MenuCallbackHandler.SpecialUnitFunction_fov_camer_cam_rot_x_menu_callback = function(self, item)
		SpecialUnitFunction.settings.fov_camer.cam_rot_x = math.floor(item:value())
		SpecialUnitFunction:Save()
	end
	MenuHelper:AddSlider({
		id = "SpecialUnitFunction_fov_camer_cam_rot_x_menu_callback",
		title = "SpecialUnitFunction_fov_camer_cam_rot_x_menu_title",
		callback = "SpecialUnitFunction_fov_camer_cam_rot_x_menu_callback",
		value =  SpecialUnitFunction.settings.fov_camer.cam_rot_x,
		min = -200,
		max = 200,
		step = 1,
		show_value = true,
		menu_id = SpecialUnitFunction.options_menu,
	})
	MenuCallbackHandler.SpecialUnitFunction_fov_camer_cam_rot_y_menu_callback = function(self, item)
		SpecialUnitFunction.settings.fov_camer.cam_rot_y = math.floor(item:value())
		SpecialUnitFunction:Save()
	end
	MenuHelper:AddSlider({
		id = "SpecialUnitFunction_fov_camer_cam_rot_y_menu_callback",
		title = "SpecialUnitFunction_fov_camer_cam_rot_y_menu_title",
		callback = "SpecialUnitFunction_fov_camer_cam_rot_y_menu_callback",
		value =  SpecialUnitFunction.settings.fov_camer.cam_rot_y,
		min = -200,
		max = 200,
		step = 1,
		show_value = true,
		menu_id = SpecialUnitFunction.options_menu,
	})
	MenuCallbackHandler.SpecialUnitFunction_fov_camer_cam_rot_z_menu_callback = function(self, item)
		SpecialUnitFunction.settings.fov_camer.cam_rot_z = math.floor(item:value())
		SpecialUnitFunction:Save()
	end
	MenuHelper:AddSlider({
		id = "SpecialUnitFunction_fov_camer_cam_rot_z_menu_callback",
		title = "SpecialUnitFunction_fov_camer_cam_rot_z_menu_title",
		callback = "SpecialUnitFunction_fov_camer_cam_rot_z_menu_callback",
		value =  SpecialUnitFunction.settings.fov_camer.cam_rot_z,
		min = -200,
		max = 200,
		step = 1,
		show_value = true,
		menu_id = SpecialUnitFunction.options_menu,
	})
	MenuCallbackHandler.SpecialUnitFunction_fov_camer_x_menu_callback = function(self, item)
		SpecialUnitFunction.settings.fov_camer.x = math.floor(item:value())
		SpecialUnitFunction:Save()
	end
	MenuHelper:AddSlider({
		id = "SpecialUnitFunction_fov_camer_x_menu_callback",
		title = "SpecialUnitFunction_fov_camer_x_menu_title",
		callback = "SpecialUnitFunction_fov_camer_x_menu_callback",
		value =  SpecialUnitFunction.settings.fov_camer.x,
		min = -200,
		max = 200,
		step = 1,
		show_value = true,
		menu_id = SpecialUnitFunction.options_menu,
	})
	MenuCallbackHandler.SpecialUnitFunction_fov_camer_y_menu_callback = function(self, item)
		SpecialUnitFunction.settings.fov_camer.y = math.floor(item:value())
		SpecialUnitFunction:Save()
	end
	MenuHelper:AddSlider({
		id = "SpecialUnitFunction_fov_camer_y_menu_callback",
		title = "SpecialUnitFunction_fov_camer_y_menu_title",
		callback = "SpecialUnitFunction_fov_camer_y_menu_callback",
		value =  SpecialUnitFunction.settings.fov_camer.y,
		min = -200,
		max = 200,
		step = 1,
		show_value = true,
		menu_id = SpecialUnitFunction.options_menu,
	})
	MenuCallbackHandler.SpecialUnitFunction_fov_camer_z_menu_callback = function(self, item)
		SpecialUnitFunction.settings.fov_camer.z = math.floor(item:value())
		SpecialUnitFunction:Save()
	end
	MenuHelper:AddSlider({
		id = "SpecialUnitFunction_fov_camer_z_menu_callback",
		title = "SpecialUnitFunction_fov_camer_z_menu_title",
		callback = "SpecialUnitFunction_fov_camer_z_menu_callback",
		value =  SpecialUnitFunction.settings.fov_camer.z,
		min = -200,
		max = 200,
		step = 1,
		show_value = true,
		menu_id = SpecialUnitFunction.options_menu,
	})
end)

Hooks:Add("MenuManagerBuildCustomMenus", "SpecialUnitFunctionOptions", function(menu_manager, nodes)
	nodes[SpecialUnitFunction.options_menu] = MenuHelper:BuildMenu( SpecialUnitFunction.options_menu )
	MenuHelper:AddMenuItem(nodes["blt_options"], SpecialUnitFunction.options_menu, "SpecialUnitFunction_menu_title", "SpecialUnitFunction_menu_desc")
end)

if ModCore then
	ModCore:new(SpecialUnitFunction.ModPath .. "Config.xml", false, true):init_modules()
end