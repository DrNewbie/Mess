_G.SpecialUnitFunction = _G.SpecialUnitFunction or {}

Hooks:PostHook(PlayerCamera, "init", "SpecialUnit_PlayerCamera_init", function(self, ...)
	self._tp_camera_object = World:create_camera()
	self._tp_camera_object:set_near_range(3)
	self._tp_camera_object:set_far_range(250000)
	self._tp_camera_object:set_fov(75)
	self._tp_camera_object:link(self._camera_object)	
	local cam_rot = self._camera_object:rotation()
	local cam_rot_x, cam_rot_y, cam_rot_z, x, y, z = 0, -60, 60, 0, 0, 100
	if SpecialUnitFunction and SpecialUnitFunction.settings and SpecialUnitFunction.settings.fov_camer then
		local fov_camer = SpecialUnitFunction.settings.fov_camer
		cam_rot_x, cam_rot_y, cam_rot_z, x, y, z = fov_camer.cam_rot_x, fov_camer.cam_rot_y, fov_camer.cam_rot_z , fov_camer.x, fov_camer.y, fov_camer.z
	end
	self._tp_camera_object:set_position(self._camera_object:position() + (cam_rot:x() * cam_rot_x) + (cam_rot:y() * cam_rot_y) + (cam_rot:z() * cam_rot_z) + Vector3(x, y, z))
	self._vp:set_camera(self._tp_camera_object)
	SpecialUnitFunction.CAMERA = self
end)

function PlayerCamera:set_FOV(fov_value)
	self._camera_object:set_fov(fov_value)
	self._tp_camera_object:set_fov(fov_value)
end

local SpecialUnit_PlayerCamera_set_position = PlayerCamera.set_position
function PlayerCamera:set_position(pos)
	if managers.player._special_unit:is_ragdoll() then
		pos = managers.player._special_unit:get_body_position()
	end
	SpecialUnit_PlayerCamera_set_position(self, pos)
end

Hooks:PostHook(PlayerCamera, "set_rotation", "SpecialUnit_PlayerCamera_set_rotation", function(self, rot)
	managers.player._special_unit:set_rotation(rot)
end)