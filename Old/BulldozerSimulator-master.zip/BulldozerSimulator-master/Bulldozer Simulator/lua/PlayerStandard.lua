PlayerStandard.MOVER_STAND = Idstring("duck")

Hooks:PostHook(PlayerStandard, "init", "SpecialUnit_PlayerStandard_init", function(self, ...)
	self._slotmask_bullet_impact_targets = self._slotmask_bullet_impact_targets - 2
	if self._unit:mover() then
		self._unit:kill_mover()
		self:_activate_mover(PlayerStandard.MOVER_STAND)
	end
	self._primary_attack_delay = 0
	self._unit_alive_track_dealy = 0
	self._unit_alive_track = 0
	self._unit_alive_track_bool = false
end)

Hooks:PostHook(PlayerStandard, "update", "SpecialUnit_PlayerStandard_update", function(self, t, dt)
	managers.player._special_unit:update(t, dt)
	if self._unit_alive_track_dealy > t then
		return
	end
	self._unit_alive_track_dealy = t + 3
	if Utils:IsInHeist() then
		if managers.player._special_unit:unit_alive() and not self._unit_alive_track_bool then
			self._unit_alive_track = t + 1
			self._unit_alive_track_bool = true
			dofile("mods/Bulldozer Simulator/Compatible/WolfHUD/copdamage.lua")
			dofile("mods/Bulldozer Simulator/Compatible/Damage2Player/copdamage.lua")
			dofile("mods/Bulldozer Simulator/Compatible/NoMarkEnemy/contourext.lua")
			dofile("mods/Bulldozer Simulator/Compatible/NoMarkEnemy/unitnetworkhandler.lua")
			dofile("mods/Bulldozer Simulator/Compatible/FixGameCrashWhenWin/missionendstate.lua")
			managers.player._special_unit:unit():brain():set_active(false, true)
		end
		if managers.player._special_unit:unit():character_damage():dead() and self._unit_alive_track > 0 and self._unit_alive_track_bool then
			managers.player:force_drop_carry()
			managers.statistics:downed({ death = true })
			IngameFatalState.on_local_player_dead()
			game_state_machine:change_state_by_name("ingame_waiting_for_respawn")
			self._unit:character_damage():set_invulnerable(true)
			self._unit:character_damage():set_health(0)
			self._unit:base():_unregister()
			self._unit:base():set_slot(self._unit, 0)
			self._unit_alive_track = 0
			managers.player._special_unit:delete_unit()
		end
	end
end)

local SpecialUnit_PlayerStandard_get_input = PlayerStandard._get_input
function PlayerStandard:_get_input(t, dt)
	local input = SpecialUnit_PlayerStandard_get_input(self, t, dt)
	if managers.player._special_unit:is_ragdoll() then
		for i,v in pairs(input)do
			if v and (i == "btn_primary_attack_state") then
				managers.player._special_unit:update_ragdoll_velocity(2)
			end
			if i ~= "btn_weapon_gadget_press" and i ~= "btn_melee_press" then
				input[i] = false
			end
		end
	end
	return input
end

Hooks:PostHook(PlayerStandard, "enter", "SpecialUnit_PlayerStandard_enter", function(self, state_data, enter_data)
	managers.player._special_unit:stop_sound()
	managers.player._special_unit:revive()
end)

local SpecialUnit_PlayerStandard_stance_entered = PlayerStandard._stance_entered
function PlayerStandard:_stance_entered(unequipped)
	local def = self._state_data.ducking
	self._state_data.ducking = true
	SpecialUnit_PlayerStandard_stance_entered(self, unequipped)
	self._state_data.ducking = def
end

Hooks:PostHook(PlayerStandard, "_determine_move_direction", "SpecialUnit_PlayerStandard_determine_move_direction", function(self, ...)
	if managers.player._special_unit:is_ragdoll() then
		if self._move_dir then
			managers.player._special_unit:update_ragdoll_velocity(2)
		end
		self._move_dir = nil
		self._normal_move_dir = nil
	end
end)

Hooks:PostHook(PlayerStandard, "_update_movement", "SpecialUnit_PlayerStandard_update_movement", function(self, ...)
	local anim_side = "idle"
	if self._last_velocity_xy then
		local fwd_new = managers.player._special_unit:unit():rotation():y()
		local right_new = fwd_new:cross(math.UP)
		local walk_dir_flat = self._last_velocity_xy:with_z(0)
		mvector3.normalize(walk_dir_flat)
		local fwd_dot = walk_dir_flat:dot(fwd_new)
		local right_dot = walk_dir_flat:dot(right_new)
		if math.abs(fwd_dot + 0.1) > math.abs(right_dot) then
			anim_side = fwd_dot > 0 and "walk_fwd" or "walk_bwd"
		else
			anim_side = right_dot > 0 and "walk_l" or "walk_r"
		end
		local vel_len = mvector3.length(self._last_velocity_xy)
		if vel_len > 700 and anim_side == "walk_fwd" then
			anim_side = "sprint_fwd"
		elseif vel_len > 700 and anim_side == "walk_bwd" then
			anim_side = "sprint_bwd"
		elseif vel_len > 700 and anim_side == "walk_l" then
			anim_side = "sprint_l"
		elseif vel_len > 700 and anim_side == "walk_r" then
			anim_side = "sprint_r"
		elseif vel_len < 1 then
			anim_side = "idle"
		end
	end
	if self._last_anim_goat ~= anim_side then
		managers.player._special_unit:unit():movement():play_redirect(anim_side)
		self._last_anim_goat = anim_side
	end
end)

Hooks:PostHook(PlayerStandard, "_update_foley", "SpecialUnit_PlayerStandard_update_foley", function(self, ...)
	if not self._state_data.in_air and managers.player._special_unit:pitch() ~= 0 then
		local o = 10
		local p = managers.player._special_unit:pitch() or 0
		if o < p and (360 - o) > p then
			managers.player._special_unit:ragdoll()
		end
		managers.player._special_unit:set_pitch(0)
	end
end)

function PlayerStandard:_check_action_steelsight(t, input)
end

function PlayerStandard:_special_unit_attack_damage(t, data)
	if not managers.player._special_unit:can_walk() then
		return
	end
	if data.type == "primary" then
		local _weap_unit = data.weapon_unit
		local _weapon_base = _weap_unit:base()
		if _weapon_base:clip_empty() then
			_weap_unit:base():on_reload()
			return
		end
		local from = _weap_unit:position() + Vector3(0,0,50)
		local to = Vector3()
		mvector3.set(to, self._unit:camera():rotation():y())
		mvector3.multiply(to, 20000)
		mvector3.add(to, from)			
		local col_ray = self._unit:raycast("ray", from, to, "ignore_unit", managers.player._special_unit:unit(), "slot_mask", self._slotmask_bullet_impact_targets)
		if not col_ray or not col_ray.ray then
			return
		end
		local target_vec = col_ray.ray
		if col_ray.unit then
			local damage = 20
			local hit_unit = col_ray.unit
			if hit_unit:damage() and col_ray.body:extension() and col_ray.body:extension().damage then
				col_ray.body:extension().damage:damage_bullet(self._unit, col_ray.normal, col_ray.position, col_ray.ray, damage)
				if hit_unit:id() ~= -1 then
					managers.network:session():send_to_peers_synched("sync_body_damage_bullet", col_ray.body, self._unit, col_ray.normal, col_ray.position, col_ray.ray, damage)
				end
			end
			local character_unit, shield
			if hit_unit:in_slot(8) and alive(hit_unit:parent()) then
				character_unit = hit_unit:parent()
				shield = hit_unit
			end
			character_unit = character_unit or hit_unit
			if character_unit:character_damage() and character_unit:character_damage().damage_bullet then
				local action_data = {}
				action_data.variant = "bullet"
				action_data.damage = damage
				action_data.weapon_unit = _weap_unit
				action_data.attacker_unit = self._unit
				action_data.col_ray = col_ray
				character_unit:character_damage():damage_bullet(action_data)
			end
			_weapon_base:singleshot(from, target_vec, 5)
		end
	end
	if data.type == "melee" then
		self._state_data.meleeing = nil
		self._state_data.melee_feet = nil
		local range = 150
		local from = managers.player._special_unit:unit():position() + SpecialUnit.HEIGHT
		local to = from + managers.player._special_unit:unit():rotation():y() * range * 1
		local sphere_cast_radius = 60
		local col_ray = self._unit:raycast("ray", from, to, "ignore_unit", managers.player._special_unit:unit(), "slot_mask", self._slotmask_bullet_impact_targets, "sphere_cast_radius", sphere_cast_radius, "ray_type", "body melee")
		if col_ray then
			local damage = 50
			col_ray.sphere_cast_radius = sphere_cast_radius
			local hit_unit = col_ray.unit
			managers.game_play_central:play_impact_flesh({col_ray = col_ray})
			managers.game_play_central:play_impact_sound_and_effects({
				col_ray = col_ray,
				no_decal = true,
				no_sound = true
			})
			if hit_unit:damage() and col_ray.body:extension() and col_ray.body:extension().damage then
				col_ray.body:extension().damage:damage_melee(self._unit, col_ray.normal, col_ray.position, col_ray.ray, damage)
				if hit_unit:id() ~= -1 then
					managers.network:session():send_to_peers_synched("sync_body_damage_melee", col_ray.body, self._unit, col_ray.normal, col_ray.position, col_ray.ray, damage)
				end
			end
			local character_unit, shield
			if hit_unit:in_slot(8) and alive(hit_unit:parent()) then
				character_unit = hit_unit:parent()
				shield = hit_unit
			end
			character_unit = character_unit or hit_unit
			if character_unit:character_damage() and character_unit:character_damage().damage_melee then
				local action_data = {}
				action_data.variant = "melee"
				action_data.damage = damage
				action_data.damage_effect = damage
				action_data.attacker_unit = self._unit
				action_data.col_ray = col_ray
				action_data.name_id = "fists"
				action_data.charge_lerp_value = 0
				local defense_data = CopDamage.damage_melee(character_unit:character_damage(), action_data)--character_unit:character_damage():damage_melee(action_data)
			end
		end
	end
	return col_ray
end

function PlayerStandard:_check_action_primary_attack(t, input)
	if self._primary_attack_delay < t then
		self._primary_attack_delay = t + 0.1
		local action_wanted = input.btn_primary_attack_state or input.btn_primary_attack_release
		if action_wanted then
			local action_forbidden = self:_is_reloading() or self:_changing_weapon() or self:_is_meleeing() or self._use_item_expire_t or self:_interacting() or self:_is_throwing_projectile() or self:_is_deploying_bipod()
			if not action_forbidden then
				local _weap_unit = managers.player._special_unit:unit():inventory():equipped_unit() or nil
				if _weap_unit then
					self:_special_unit_attack_damage(t, {
						type = "primary",
						weapon_unit = _weap_unit
					})
				end
			end
		end
	end
	return
end

function PlayerStandard:_check_action_melee(t, input)
	local action_wanted = input.btn_melee_press or input.btn_melee_release or self._state_data.melee_charge_wanted
	if not action_wanted then
		return
	end
	local action_forbidden = not self:_melee_repeat_allowed() or self._use_item_expire_t or self:_changing_weapon() or self:_interacting() or self:_is_throwing_projectile() or self:_is_using_bipod()
	if action_forbidden then
		return
	end
	self:_special_unit_attack_damage(t, {
		type = "melee"
	})
	self._state_data.melee_expire_t = self._state_data.melee_expire_t or 0
	if input.btn_melee_press and self._state_data.melee_expire_t and t >= self._state_data.melee_expire_t then
		managers.player._special_unit:do_melee_attack(t)
		self._state_data.melee_expire_t = t + 0.4
	end
	return
end