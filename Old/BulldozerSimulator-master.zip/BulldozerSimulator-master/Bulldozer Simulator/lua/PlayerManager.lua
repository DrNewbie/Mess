_G.SpecialUnitFunction = _G.SpecialUnitFunction or {}

SpecialUnit = SpecialUnit or class()
SpecialUnit.HEIGHT = Vector3(0,0,100)
SpecialUnit.MASS_CENTER = 40
SpecialUnit.ANIM_DATA = {
	anim_walk_fwd = {0,1},
	anim_back = {0,1},
	anim_right_strafe = {0,1},
	anim_left_strafe = {0,1},
	anim_sprint = {0,1},
	startup = {0,1},
	anim_attack_head = {0.7,2},
	anim_attack_feet = {1.1,2},
}

function SpecialUnit:init()
	self._unit_name = SpecialUnitFunction._unit_name
end

function SpecialUnit:init_unit(data)
	self._rot_p = 0
	self._parent_unit = data._parent
	self._unit = World:spawn_unit(self._unit_name, self._parent_unit:position(), Rotation())
	self._parent_unit:link(data._parent:orientation_object():name(), self._unit, self._unit:orientation_object():name())
	self._unit:set_slot(12)
	self._unit = self._unit
	self._unit:movement():set_team(managers.groupai:state():team_data(tweak_data.levels:get_default_team_ID("combatant")))
	self._unit:brain():set_active(true, true)
	if data._to_criminal then
		managers.groupai:state():convert_hostage_to_criminal(self._unit, self._parent_unit)
	end
	self._unit:character_damage():set_invulnerable(true)
end

function SpecialUnit:update(t, dt)
end

function SpecialUnit:unit()
	return self._unit
end

function SpecialUnit:parent()
	return self._parent_unit
end

function SpecialUnit:do_melee_attack(t)
	local melee_weapon = self._unit:base():melee_weapon()
	local is_weapon = melee_weapon == "weapon"
	local state = self._unit:movement():play_redirect(is_weapon and "melee" or "melee_item")
	if state then
		if not is_weapon then
			local anim_attack_vars = {"var1", "var2"}
			self._unit:anim_state_machine():set_parameter(state, anim_attack_vars[math.random(#anim_attack_vars)], 1)
			local param = tweak_data.weapon.npc_melee[melee_weapon].animation_param
			self._unit:anim_state_machine():set_parameter(state, param, 1)
		end
		if is_weapon then
			local anim_speed = 1
			self._unit:anim_state_machine():set_speed(state, anim_speed)
		end
		self._melee_timeout_t = TimerManager:game():time() + 1
	end
end

function SpecialUnit:delete_unit()
	if self:unit_alive() then
		World:delete_unit(self._unit)
	end
end

function SpecialUnit:unit_alive()
	if alive(self._unit) then
		return true
	end
end

function SpecialUnit:get_body_position()
	if self:unit_alive() then
		return self._unit:body(0):position() + Vector3(0,0,60)
	end
end

function SpecialUnit:stop_sound()
	if not self:unit_alive() then
		return
	end
	self._unit:sound_source():stop()
end

function SpecialUnit:play_seq(seq)
	if not self:unit_alive() then
		return
	end
	self._unit:movement():play_redirect(seq)
end

function SpecialUnit:anim_leng(anim)
	local d = self.ANIM_DATA[anim]
	return d and d[1]
end

function SpecialUnit:anim_type(anim)
	local d = self.ANIM_DATA[anim]
	return d and d[2]
end

function SpecialUnit:set_rotation(rot)
	if self:can_walk() then
		self._unit:set_rotation(Rotation(rot:yaw(), self._rot_p, rot:roll()))
		local plr_rot = managers.player:player_unit():movement():m_head_rot()
		local p_rot = Rotation(plr_rot:yaw(), 0, plr_rot:roll())
		self._unit:set_position(managers.player:player_unit():position() - p_rot:z() * (math.cos(self._rot_p) * self.MASS_CENTER - self.MASS_CENTER) + p_rot:y() * math.sin(self._rot_p) * self.MASS_CENTER)
	end
end

function SpecialUnit:set_pitch(p)
	self._rot_p = p % 360
end

function SpecialUnit:add_pitch(p)
	self._rot_p = (self._rot_p + p) % 360
end

function SpecialUnit:pitch()
	return self._rot_p
end

function SpecialUnit:can_walk()
	if alive(self._unit) and not self._ragdoll then
		return true
	end
end

function SpecialUnit:ragdoll_velocity()
	local vel = self._unit:body(7):velocity()
	return mvector3.length(vel)
end

function SpecialUnit:update_ragdoll_velocity(vel)
	if self:ragdoll_velocity() < vel then
		self:revive()
	end
end

function SpecialUnit:is_ragdoll()
	return self._ragdoll
end

function SpecialUnit:switch_ragdoll()
	if not self:unit_alive() then
		return
	end
	if self:is_ragdoll() then
		self:revive()
	else
		self:ragdoll()
	end
end

function SpecialUnit:switch_ragdoll_vel()
	if not self:unit_alive() then
		return
	end
	if self:is_ragdoll() then
		self:update_ragdoll_velocity(50)
	else
		self:ragdoll()
	end
end

function SpecialUnit:ragdoll()
	return
end

function SpecialUnit:drop()
end

function SpecialUnit:revive()
	for i = 0, self._unit:num_bodies() - 1 do
		self._unit:body(i):set_enabled(i < 2)
	end
	self:play_seq("idle")
	self._ragdoll = false
	self:drop()	
	local player_unit = managers.player:player_unit()
	if alive(player_unit) then
		player_unit:movement():set_position(self._unit:body(0):position())
	end
end

Hooks:PostHook(PlayerManager, "init", "SpecialUnit_PlayerManager_init", function(self)
	self._special_unit = SpecialUnit:new(data)
end)