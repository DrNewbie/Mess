Hooks:PostHook(PlayerBase, "init", "SpecialUnit_PlayerBase_init", function(self, unit)
	managers.player._special_unit:init_unit({_parent = unit, _to_criminal = true})
end)

Hooks:PostHook(PlayerBase, "pre_destroy", "SpecialUnit_PlayerBase_pre_destroy", function(self, ...)
	managers.player._special_unit:delete_unit()
end)