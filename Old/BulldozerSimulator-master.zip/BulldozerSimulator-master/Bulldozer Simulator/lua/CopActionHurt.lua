function CopActionHurt:_freeze_ragdoll()
end
function CopActionHurt:clbk_chk_freeze_ragdoll()
end