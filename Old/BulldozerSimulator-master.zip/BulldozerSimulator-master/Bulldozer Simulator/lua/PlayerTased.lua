function PlayerTased:_check_action_primary_attack(t, input)
	return
end