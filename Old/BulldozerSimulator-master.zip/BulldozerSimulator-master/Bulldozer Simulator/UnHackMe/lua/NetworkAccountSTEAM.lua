
--[[
Disable statistics
Used for FBI files and pd2stats.com, we don't wanna bring chaos there.
should also prevent some unwanted "cheater" taggings related to skills and maybe others
]]
function NetworkAccountSTEAM:publish_statistics(stats, force_store, ...)
	return
end
