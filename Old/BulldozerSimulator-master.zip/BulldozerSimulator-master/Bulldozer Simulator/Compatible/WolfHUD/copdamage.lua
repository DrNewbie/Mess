--[[
	function CopDamage:_process_kill(data)
		local killer
		local weapon_type
		local weapon_slot
		
		local attacker = alive(data.attacker_unit) and data.attacker_unit

		if attacker then
			if attacker:in_slot(3) or attacker:in_slot(5) then	
				--Human team mate
				killer = attacker
			elseif attacker:in_slot(2) then
				--Player
				killer = attacker
			elseif attacker:in_slot(16) then
				--Bot/joker
				killer = attacker
			elseif attacker:in_slot(12) then
				--Enemy
			elseif attacker:in_slot(25)	then
				--Turret
				local owner = attacker:base():get_owner_id()
				if owner then 
					killer =  managers.criminals:character_unit_by_peer_id(owner)
				end
			elseif attacker:base().thrower_unit then
				killer = attacker:base():thrower_unit()
			end
			
			if alive(killer) then
				local is_special = managers.groupai:state():is_enemy_special(self._unit) or (self._unit:base()._tweak_table == "sniper")
				local i_body = data.col_ray and data.col_ray.body and self._unit:get_body_index(data.col_ray.body:name())
				local body_name
				local headshot = false
				if not i_body or i_body <= 0 then
				else
					body_name = i_body and self._unit:body(i_body) and self._unit:body(i_body):name()
					headshot = self._head_body_name and body_name and body_name == self._ids_head_body_name or false
				end
				if killer:in_slot(2) then
					managers.hud:increment_teammate_kill_count(HUDManager.PLAYER_PANEL, is_special, headshot)
				else
					local crim_data = managers.criminals:character_data_by_unit(killer)
					if crim_data and crim_data.panel_id then
						managers.hud:increment_teammate_kill_count(crim_data.panel_id, is_special, headshot)
					end
				end
			end
		end
	end
]]