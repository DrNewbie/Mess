function SpecialUnit_Damage_Fixed(damage)
	return damage * 1.1
end

local SpecialUnit_Hurt_Event_t = 0
function SpecialUnit_Hurt_Event()
	local _now_time = math.floor(TimerManager:game():time())
	if SpecialUnit_Hurt_Event_t > _now_time then
		return
	end
	managers.player:local_player():sound():stop()
	if math.random(1, 4) == 1 then
		managers.player._special_unit:unit():sound():say("bdz_visor_lost", nil, true)
	else
		managers.player._special_unit:unit():sound():say("bdz_x01a_any_3p", nil, true)
	end
	SpecialUnit_Hurt_Event_t = _now_time + 30
end

local SpecialUnit_Kill_Event_t = 0
function SpecialUnit_Kill_Event()
	local _now_time = math.floor(TimerManager:game():time())
	if SpecialUnit_Kill_Event_t > _now_time then
		return
	end
	managers.player:local_player():sound():stop()
	local _play_list = {"bdz_c01", "bdz_entrance", "bdz_entrance_elite", "bdz_g90", "bdz_post_kill_taunt"}
	managers.player._special_unit:unit():sound():say(_play_list[math.random(#_play_list)], nil, true)
	SpecialUnit_Kill_Event_t = _now_time + 30
end

function CopDamage:can_be_critical()
end

local SpecialUnit_CopDamage_damage_melee = CopDamage.damage_melee
function CopDamage:damage_melee(attack_data)
	if self._unit == managers.player._special_unit:unit() and managers.player._special_unit:parent() then
		attack_data.damage = SpecialUnit_Damage_Fixed(attack_data.damage)
		SpecialUnit_Hurt_Event()
		managers.player._special_unit:parent():character_damage():damage_melee(attack_data)
		return
	end
	return SpecialUnit_CopDamage_damage_melee(self, attack_data)
end

local SpecialUnit_CopDamage_damage_explosion = CopDamage.damage_explosion
function CopDamage:damage_explosion(attack_data)
	if self._unit == managers.player._special_unit:unit() and managers.player._special_unit:parent() then
		attack_data.damage = SpecialUnit_Damage_Fixed(attack_data.damage)
		SpecialUnit_Hurt_Event()
		if attack_data.attacker_unit == managers.player._special_unit:parent() then
			return
		end
		managers.player._special_unit:parent():character_damage():damage_explosion(attack_data)
		return
	end
	return SpecialUnit_CopDamage_damage_explosion(self, attack_data)
end

local SpecialUnit_CopDamage_damage_fire = CopDamage.damage_fire
function CopDamage:damage_fire(attack_data)
	if self._unit == managers.player._special_unit:unit() and managers.player._special_unit:parent() then
		attack_data.damage = SpecialUnit_Damage_Fixed(attack_data.damage)
		SpecialUnit_Hurt_Event()
		if attack_data.attacker_unit == managers.player._special_unit:parent() then
			return
		end
		managers.player._special_unit:parent():character_damage():damage_fire(attack_data)
		return
	end
	return SpecialUnit_CopDamage_damage_fire(self, attack_data)
end

function CopDamage:damage_tase(attack_data)
end

local SpecialUnit_CopDamage_damage_bullet = CopDamage.damage_bullet
function CopDamage:damage_bullet(attack_data)
	if self._unit == managers.player._special_unit:unit() and managers.player._special_unit:parent() then
		attack_data.damage = SpecialUnit_Damage_Fixed(attack_data.damage)
		SpecialUnit_Hurt_Event()
		managers.player._special_unit:parent():character_damage():damage_bullet(attack_data)
		return
	end
	return SpecialUnit_CopDamage_damage_bullet(self, attack_data)
end

local SpecialUnit_CopDamage_damage_killzone = CopDamage.damage_killzone
function CopDamage:damage_killzone(attack_data)
	if self._unit == managers.player._special_unit:unit() and managers.player._special_unit:parent() then
		attack_data.damage = SpecialUnit_Damage_Fixed(attack_data.damage)
		SpecialUnit_Hurt_Event()
		if attack_data.attacker_unit == managers.player._special_unit:parent() then
			return
		end
		managers.player._special_unit:parent():character_damage():damage_killzone(attack_data)
		return
	end
	return SpecialUnit_CopDamage_damage_killzone(self, attack_data)
end

Hooks:PostHook(CopDamage, "_on_death", "SpecialUnit_CopDamage_on_death", function(self, ...)
	if managers.player._special_unit:unit() and managers.player._special_unit:parent() then
		SpecialUnit_Kill_Event()
	end
end)