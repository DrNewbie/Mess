if Network:is_client() then
	return
end

if not Global.game_settings or not Global.game_settings.level_id:find('election_day_3') then
	return
end

_G.Election_Day3_Stealth = _G.Election_Day3_Stealth or {}
Election_Day3_Stealth = _G.Election_Day3_Stealth
Election_Day3_Stealth.this_executed = Election_Day3_Stealth.this_executed or {}

Election_Day3_Stealth.DummySurprise = 3

if math.random(1, 3) == 1 then
	Election_Day3_Stealth.DummySurprise = 0
end

local ED3S_Dummy_get_orientation = ElementSpawnEnemyDummy.get_orientation

function ElementSpawnEnemyDummy:get_orientation(...)
	local pos, rot = ED3S_Dummy_get_orientation(self, ...)
	--Move Near Door to More Right So Civ Can't See Him
	if self._id == 102643 then
		pos = Vector3(1200, -200, 0)
	end
	if Election_Day3_Stealth.DummySurprise == 1 then
		Election_Day3_Stealth.DummySurprise = 2
		pos = Vector3(2315, -2715, 0)
	end
	return pos, rot
end

local ED3S_SpawnEnemyDummy = ElementSpawnEnemyDummy.produce

function ElementSpawnEnemyDummy:produce(params)
	--No Those Cop
		if (self._id == 103553 and Election_Day3_Stealth.DummySurprise ~= 1) or self._id == 103540 or self._id == 103957 or 
			self._id == 102513 or self._id == 103957 then
			return nil
		end
	--No Escape Cop
	if managers.groupai:state():whisper_mode() then
		if self._id == 100267 or self._id == 100268 or self._id == 100270 or self._id == 100271 or
			self._id == 100272 or self._id == 100273 or self._id == 100274 or self._id == 100293 or
			self._id == 100294 or self._id == 100295 or self._id == 100298 or self._id == 100299 or
			self._id == 100300 or self._id == 100301 or self._id == 100302 or self._id == 100304 or
			self._id == 100305 or self._id == 100306 or self._id == 100307 or self._id == 100308 or
			self._id == 100309 or self._id == 100310 or self._id == 100311 or self._id == 100141 or
			self._id == 100361 or self._id == 100368 or self._id == 103348 or self._id == 103349 or 
			self._editor_name:find('escape1_other_side') then
			Election_Day3_Stealth:Loud_Run_Script(self._id)
			if Election_Day3_Stealth.DummySurprise == 0 then
				Election_Day3_Stealth.DummySurprise = 1
				Election_Day3_Stealth:Run_Script(103553)
			else
				return nil
			end
		end
	end
	local COP_unit = ED3S_SpawnEnemyDummy(self, params)
	if self._id == 103553 and Election_Day3_Stealth.DummySurprise == 2 then
		Election_Day3_Stealth.DummySurprise = 3
		COP_unit:unit_data().has_alarm_pager = nil
	end
	return COP
end