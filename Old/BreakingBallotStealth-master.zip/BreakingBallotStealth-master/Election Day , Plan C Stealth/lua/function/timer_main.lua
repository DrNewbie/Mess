if Network:is_client() then
	return
end

if not Global.game_settings or not Global.game_settings.level_id:find('election_day_3') then
	return
end

_G.Election_Day3_Stealth = _G.Election_Day3_Stealth or {}

Hooks:Add("GameSetupUpdate", "ED3S_TimerMain", function(t, dt)
	Election_Day3_Stealth:Timer_Main(t)
end)

Election_Day3_Stealth.Enable = true
Election_Day3_Stealth.Timer_Enable = false
Election_Day3_Stealth.OopsLoud = false
Election_Day3_Stealth.Start_Time = 0
Election_Day3_Stealth.Timer_Main_Repeat_Dealy = 0
Election_Day3_Stealth.Delay2Run = {}
Election_Day3_Stealth.Loud2Run = {}

function Election_Day3_Stealth:Timer_Main(t)
	if not Utils:IsInHeist() or self.Timer_Main_Repeat_Dealy > t then
		return
	end
	self.Timer_Main_Repeat_Dealy = math.floor(t) + 1
	local _nowtime = math.floor(t)
	local _start_time = self.Start_Time or 0
	self.Now_Time = _nowtime
	--Mission start
	if self and self.Enable then
		--Init
		if not self.Timer_Enable then
			self.Timer_Enable = true
			for _, unit in pairs(World:find_units_quick("all", 1)) do

			end
		end
		--Delay_Run_Script
		for asked_id, time2do in pairs(self.Delay2Run) do
			if type(time2do) == 'number' and time2do > 0 and _nowtime > time2do then
				self.Delay2Run[asked_id] = -1
				self:Run_Script(asked_id)
			end
			if type(time2do) == 'number' and time2do <= 0 then
				self.Delay2Run[asked_id] = nil
			end
		end
		--Oops, Loud
		if not self.OopsLoud and self.this_executed['id_104525'] and not managers.groupai:state():whisper_mode() then
			self.OopsLoud = true
			for asked_id, time2do in pairs(self.Loud2Run) do
				if type(time2do) == 'number' then
					if time2do > 0 and _nowtime > time2do then
						self:Delay_Run_Script(asked_id, time2do)
						self.Loud2Run[asked_id] = -1
					end
					if time2do <= 0 then
						self.Loud2Run[asked_id] = nil
					end
				end
				if type(time2do) == 'boolean' then
					self.Loud2Run[asked_id] = nil
					self:Run_Script(asked_id)
				end
			end
		end
	end
end

function Election_Day3_Stealth:Delay_Run_Script(asked_id, time2do)
	time2do = time2do or 0
	self.Delay2Run[asked_id] = TimerManager:game():time() + time2do
end

function Election_Day3_Stealth:Loud_Run_Script(asked_id, time2do)
	time2do = time2do or 0
	if time2do > 0 then
		self.Loud2Run[asked_id] = TimerManager:game():time() + time2do
	else
		self.Loud2Run[asked_id] = true
	end
end

function Election_Day3_Stealth:Run_Script(asked_id)
	for _, script in pairs(managers.mission:scripts()) do
		for id, element in pairs(script:elements()) do
			if id == asked_id then
				element:on_executed()
				return
			end
		end
	end
end