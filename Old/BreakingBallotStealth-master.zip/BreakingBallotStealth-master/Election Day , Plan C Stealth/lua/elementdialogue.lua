if Network:is_client() then
	return
end

if not Global.game_settings or not Global.game_settings.level_id:find('election_day_3') then
	return
end

core:import("CoreMissionScriptElement")
ElementDialogue = ElementDialogue or class(CoreMissionScriptElement.MissionScriptElement)

local ED3S_ElementDialogue = ElementDialogue.on_executed

function ElementDialogue:on_executed(...)
	--No Wall Bomb
	if self._id == 103373 or self._id == 104799 then
		return nil
	end
	return ED3S_ElementDialogue(self, ...)
end