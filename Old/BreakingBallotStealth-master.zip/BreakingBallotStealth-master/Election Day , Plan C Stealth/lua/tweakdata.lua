tweak_data.levels["election_day_3"].ghost_bonus = 0.30
tweak_data.levels["election_day_3_skip1"].ghost_bonus = 0.30
tweak_data.levels["election_day_3_skip2"].ghost_bonus = 0.30