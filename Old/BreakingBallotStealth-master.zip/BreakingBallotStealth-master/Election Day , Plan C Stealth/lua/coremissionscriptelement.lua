if Network:is_client() then
	return
end

if not Global.game_settings or not Global.game_settings.level_id:find('election_day_3') then
	return
end

core:module("CoreMissionScriptElement")
core:import("CoreXml")
core:import("CoreCode")
core:import("CoreClass")

_G.Election_Day3_Stealth = _G.Election_Day3_Stealth or {}
Election_Day3_Stealth = _G.Election_Day3_Stealth
Election_Day3_Stealth.this_executed = Election_Day3_Stealth.this_executed or {}

local ED3S_MissionScriptElement_on_executed = MissionScriptElement.on_executed

function MissionScriptElement:on_executed(...)
	local _id = tostring('id_' .. self._id)
	if not Election_Day3_Stealth.this_executed[_id] then
		Election_Day3_Stealth.this_executed[_id] = true
		--After Hacked, Open Shutters
		if _id == 'id_104522' then
			Election_Day3_Stealth:Delay_Run_Script(103472, 1)
		end
		--Faster Hacking Speed
		if _id == 'id_103568' then
			Election_Day3_Stealth:Delay_Run_Script(103575, 15 + math.floor(math.random()*10))
		end
		--Hold It, Don't Bomb
		if _id == 'id_104525' then
			Election_Day3_Stealth:Delay_Run_Script(103466, 1)
			Election_Day3_Stealth:Delay_Run_Script(101456, 1)
			Election_Day3_Stealth:Delay_Run_Script(101301, 1)
			Election_Day3_Stealth:Loud_Run_Script(104524)
			Election_Day3_Stealth:Loud_Run_Script(104526)
			Election_Day3_Stealth:Loud_Run_Script(104631)
			Election_Day3_Stealth:Loud_Run_Script(102714)
			Election_Day3_Stealth:Loud_Run_Script(104774)
			Election_Day3_Stealth:Loud_Run_Script(104773)
			Election_Day3_Stealth:Loud_Run_Script(104782)
			Election_Day3_Stealth:Loud_Run_Script(103136)
			Election_Day3_Stealth:Loud_Run_Script(100528)
			Election_Day3_Stealth:Loud_Run_Script(103996)
		end
	end
	local Block_Script = {
		id_103571 = true, --Hacking No ShutDown
		id_103942 = true, --No Entrance Guard
		id_104525 = true, --Don't Bomb Wall
	}	
	if Block_Script[_id] then
		return
	end
	return ED3S_MissionScriptElement_on_executed(self, ...)
end
	