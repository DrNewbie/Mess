KillGainEXPNOW = KillGainEXPNOW or class()
function KillGainEXPNOW:init(hud)  
	self._full_hud = hud
	self._killgetexp_panel = self._full_hud:panel({
		name = "killgetexp_panel", 
		alpha = 0,
		layer = 100,
		valign = "center", 
		halign = "center",
	})
	self._killgetexp_text = self._killgetexp_panel:text({
		name = "kill_text",
		vertical = "bottom",
		align = "center",
		text = "0",
		font_size = 24,
		layer = 2,
		color = Color.black,
		font = "fonts/font_large_mf"
	})   
	self._killgetexp_panel:rect({
		name = "kill_bg",
		halign = "grow",
		valign = "grow",
		layer = 1,
		color = Color.black 
	})	 
	local x,y,w,h = self._killgetexp_text:text_rect()
	self._killgetexp_panel:set_size(w + 6,h + 4)
	self._killgetexp_text:set_size(w,h)
	self._killgetexp_panel:set_center(self._full_hud:center_x(), self._full_hud:center_y() - 250)
end

function KillGainEXPNOW:SetGain(Type, EXP, Combo)
	if Combo <= 0 then
		self._killgetexp_text:set_color(Color(1, 0, 0))
	else
		self._killgetexp_text:set_color(Color(0, 1, 0))
	end
	local Type_TXT = {
		"Kill"
	}
	if Type > 0 and Type <= table.size(Type_TXT) and Type_TXT[Type] then
		self._killgetexp_text:set_text("[" .. Type_TXT[Type] .. "] +" .. tostring(EXP).." EXP")
		local x,y,w,h = self._killgetexp_text:text_rect()
		self._killgetexp_panel:set_size(w + 6,h + 4)
		self._killgetexp_text:set_size(w,h)
		self._killgetexp_panel:set_center(self._full_hud:center_x(), self._full_hud:center_y() - 150)
		self._killgetexp_panel:stop()
		self._killgetexp_panel:animate(callback(self, self, "show_KillGainEXPNOW"))
	end
end

function KillGainEXPNOW:animate_combo(text)
	local t = 0
	while t < 1 do
		t = t + coroutine.yield()
		local n = 1 - math.sin(t * 360)
		text:set_font_size(math.lerp( 24 + 6, 24 , n))
		local x,y,w,h = self._killgetexp_text:text_rect()
		self._killgetexp_panel:set_size(w + 6,h + 4)
		self._killgetexp_text:set_size(w,h)   
		self._killgetexp_panel:set_center(self._full_hud:center_x(), self._full_hud:center_y() - 150)
	end
	text:set_font_size( 24 )
	local x,y,w,h = self._killgetexp_text:text_rect()
	self._killgetexp_panel:set_size(w + 6,h + 4)
	self._killgetexp_text:set_size(w,h)   
	self._killgetexp_panel:set_center(self._full_hud:center_x(), self._full_hud:center_y() - 150)
end

function KillGainEXPNOW:show_KillGainEXPNOW(rect)
	local anim_t = 3
	local t = 5 - anim_t 
	if self._started then
		self._killgetexp_text:animate(callback(self, self, "animate_combo"))
	end
	self._started = true
	while anim_t > 0 do
		anim_t = anim_t - coroutine.yield()
		local n = 1 - math.sin((anim_t / 2) * 400)	 
		if self._killgetexp_panel:alpha() < 0.99 then
		self._killgetexp_panel:set_alpha(math.lerp(1, 0, n))
		self._killgetexp_panel:set_center_x(math.lerp(self._full_hud:center_x(), self._full_hud:center_x()*1.5 - 120, n))
		end
	end
	while t < 0.5 do
		t = t + coroutine.yield()
		local n = 1 - math.sin((t / 2) * 350)	 
		self._killgetexp_panel:set_alpha(math.lerp(0, 1, n))
		self._killgetexp_panel:set_center_x(math.lerp(self._full_hud:center_x()*1.5 - 120, self._full_hud:center_x(), n))
	end
	self._started = false
	self._killgetexp_panel:set_alpha(0)
	self._killgetexp_panel:set_x(self._full_hud:center_x()*1.5 - 120)
end 