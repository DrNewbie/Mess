dofile("mods/Get EXP from Kills/hud/KillGetExp.lua")     
Hooks:PostHook(HUDManager, "_setup_player_info_hud_pd2", "setup_KillGainEXPNOW", function(self)
    self._killgetexp = KillGainEXPNOW:new(managers.gui_data:create_fullscreen_workspace():panel())  
end)
