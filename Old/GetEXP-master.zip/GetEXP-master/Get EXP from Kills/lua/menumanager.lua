if Announcer then
	Announcer:AddHostMod("Get EXP from Kills, ( http://modwork.shop/19403 )")
end

_G.WOWKillGainEXP = _G.WOWKillGainEXP or {}

WOWKillGainEXP.menu_id = "WOWKillGainEXP_menu_id"
WOWKillGainEXP.ModPath = ModPath
WOWKillGainEXP.SaveFile = WOWKillGainEXP.SaveFile or SavePath .. "WOWKillGainEXP.txt"

WOWKillGainEXP.settings = {
	HUD = 1,
	MESSAGE = 1
}

function WOWKillGainEXP:Reset()
	self.settings = {
		HUD = 1,
		MESSAGE = 1
	}
	self:Save()
end

function WOWKillGainEXP:Load(supp, current_stage)
	local _file = io.open(self.SaveFile, "r")
	if _file then
		local _data = tostring(_file:read("*all"))
		_data = _data:gsub('%[%]', '{}')
		self.settings = json.decode(_data)
		_file:close()
		self:Save()
	else
		self:Reset()
	end
end

function WOWKillGainEXP:Save()
	local _file = io.open(self.SaveFile, "w+")
	if _file then
		_file:write(json.encode(self.settings))
		_file:close()
	end
end

Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_WOWKillGainEXP", function(menu_manager, nodes)
	MenuHelper:NewMenu(WOWKillGainEXP.menu_id)
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_WOWKillGainEXP", function(menu_manager, nodes)
	MenuCallbackHandler.WOWKillGainEXP_HUD_Toggle = function(self, item)
		if tostring(item:value()) == "on" then
			WOWKillGainEXP.settings["HUD"] = 1
		else
			WOWKillGainEXP.settings["HUD"] = 0
		end
		WOWKillGainEXP:Save()
	end
	local _bool = WOWKillGainEXP.settings["HUD"] == 1 and true or false
	MenuHelper:AddToggle({
		id = "WOWKillGainEXP_HUD_Toggle",
		title = "menu_WOWKillGainEXP_HUD_name",
		desc = "menu_WOWKillGainEXP_HUD_desc",
		callback = "WOWKillGainEXP_HUD_Toggle",
		value = _bool,
		menu_id = WOWKillGainEXP.menu_id,
	})
	MenuCallbackHandler.WOWKillGainEXP_MESSAGE_Toggle = function(self, item)
		if tostring(item:value()) == "on" then
			WOWKillGainEXP.settings["MESSAGE"] = 1
		else
			WOWKillGainEXP.settings["MESSAGE"] = 0
		end
		WOWKillGainEXP:Save()
	end
	_bool = WOWKillGainEXP.settings["MESSAGE"] == 1 and true or false
	MenuHelper:AddToggle({
		id = "WOWKillGainEXP_MESSAGE_Toggle",
		title = "menu_WOWKillGainEXP_MESSAGE_name",
		desc = "menu_WOWKillGainEXP_MESSAGE_desc",
		callback = "WOWKillGainEXP_MESSAGE_Toggle",
		value = _bool,
		menu_id = WOWKillGainEXP.menu_id,
	})
end)

Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_WOWKillGainEXP", function(menu_manager, nodes)
	nodes[WOWKillGainEXP.menu_id] = MenuHelper:BuildMenu(WOWKillGainEXP.menu_id)
	MenuHelper:AddMenuItem(MenuHelper.menus.lua_mod_options_menu, WOWKillGainEXP.menu_id, "menu_WOWKillGainEXP_name", "menu_WOWKillGainEXP_desc")
end)

Hooks:Add("LocalizationManagerPostInit", "WOWKillGainEXP_loc", function(loc)
	LocalizationManager:add_localized_strings({
		["menu_WOWKillGainEXP_name"] = "Get EXP from Kills",
		["menu_WOWKillGainEXP_desc"] = " ...",
		["menu_WOWKillGainEXP_HUD_name"] = "HUD",
		["menu_WOWKillGainEXP_HUD_desc"] = " ...",
		["menu_WOWKillGainEXP_MESSAGE_name"] = "Message",
		["menu_WOWKillGainEXP_MESSAGE_desc"] = " ...",
	})
end)

WOWKillGainEXP:Load()