_G.WOWKillGainEXP = _G.WOWKillGainEXP or {}

WOWKillGainEXP._GainRate = 100

WOWKillGainEXP._Last_Kill_t = 0

WOWKillGainEXP._Combo_times = 0

function WOWKillGainEXP:EXP_Punish(_EXP)
	if self._GainRate < 0 then
		self._GainRate = 1
	end
	_EXP = _EXP * self._GainRate / 100
	return _EXP
end

Hooks:PostHook(PlayerManager, "on_killshot", "GETEXP_Post_on_killshot", function(ply, killed_unit, ...)
	local _difficulty = Global.game_settings and Global.game_settings.difficulty or "normal"
	if CopDamage.is_civilian(killed_unit:base()._tweak_table) then
		local _Diff_Bonus = {
			normal = 3,
			hard = 3,
			overkill = 7,
			overkill_145 = 7,
			easy_wish = 11,
			overkill_290 = 11,
			sm_wish = 11
		}
		WOWKillGainEXP._GainRate = WOWKillGainEXP._GainRate - (_Diff_Bonus[_difficulty] or _Diff_Bonus["sm_wish"])
		return
	end
	local _EXP = 10 + (tweak_data.character[killed_unit:base()._tweak_table].HEALTH_INIT or 0)
	local _Now_t = TimerManager:game():time() or 0
	local _dt = _Now_t - WOWKillGainEXP._Last_Kill_t
	WOWKillGainEXP._Last_Kill_t = _Now_t
	local _Combo_EXP = 0
	local _Diff_Bonus = {
		normal = 1.1,
		hard = 1.2,
		overkill = 1.25,
		overkill_145 = 2.45,
		easy_wish = 4.05,
		overkill_290 = 4.75,
		sm_wish = 5.95
	}
	_EXP = _EXP * (_Diff_Bonus[_difficulty] or _Diff_Bonus["sm_wish"])
	_EXP = _EXP / 7
	if _dt >= 0.7 or _dt <= 0 then
		_Combo_EXP = 0
	elseif _dt < 0.1 then
		_Combo_EXP = _EXP * 0.75
	elseif _dt < 0.5 then
		_Combo_EXP = _EXP * 0.47
	elseif _dt < 0.7 then
		_Combo_EXP = _EXP * 0.23
	end
	if _Combo_EXP > 0 then
		WOWKillGainEXP._Combo_times = WOWKillGainEXP._Combo_times + 1
	else
		WOWKillGainEXP._Combo_times = 0
	end
	if WOWKillGainEXP._Combo_times > 3 then
		local _Combo_EXP_Bonus = 1 + (_Combo_EXP * ( WOWKillGainEXP._Combo_times - 3 ) / 10)
		_Combo_EXP = _Combo_EXP + _Combo_EXP_Bonus
		end
	local _EXP_No_Round = 0
	local _EXP_No_Combo = math.round(WOWKillGainEXP:EXP_Punish(_EXP))
	_EXP = _EXP + _Combo_EXP
	_EXP_No_Round = WOWKillGainEXP:EXP_Punish(_EXP)
	_EXP = math.round(WOWKillGainEXP:EXP_Punish(_EXP))
	_Combo_EXP = math.round(WOWKillGainEXP:EXP_Punish(_Combo_EXP))
	if WOWKillGainEXP.settings["MESSAGE"] == 1 then
		if _Combo_EXP > 0 then
			managers.chat:_receive_message(1, "[Kill]", "+" .. _EXP_No_Combo .. " (+" .. _Combo_EXP .. ") EXP", Color.green)
		else
			managers.chat:_receive_message(1, "[Kill]", "+" .. _EXP .. " EXP", Color.green)
		end
	end
	if WOWKillGainEXP.settings["HUD"] == 1 then
		managers.hud._killgetexp:SetGain(1, _EXP, _Combo_EXP)
	end
	managers.experience:mission_xp_award(_EXP_No_Round)
end)