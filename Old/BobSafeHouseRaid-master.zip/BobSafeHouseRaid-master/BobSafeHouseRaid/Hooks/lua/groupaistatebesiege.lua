function GroupAIStateBesiege:special_assault_function()
	self:set_wave_mode("hunt")
end