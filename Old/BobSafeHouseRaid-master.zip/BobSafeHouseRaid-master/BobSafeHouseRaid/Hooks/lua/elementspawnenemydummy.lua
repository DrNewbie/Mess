if Network:is_client() then
	return
end

_G.BobSafeHouseRaid = _G.BobSafeHouseRaid or {}

local OSHL_SpawnEnemyDummy = ElementSpawnEnemyDummy.produce

BobSafeHouseRaid.Run_Script_Table = BobSafeHouseRaid.Run_Script_Table or {}

function ElementSpawnEnemyDummy:produce(...)
	if BobSafeHouseRaid.Enable then
		local enemy_name = self:value("enemy") or self._enemy_name
		local pos, rot = self:get_orientation()
		if BobSafeHouseRaid.Run_Script_Table then
			if tostring(BobSafeHouseRaid.Run_Script_Table.ENEMY):find('Idstring') then
				enemy_name = BobSafeHouseRaid.Run_Script_Table.ENEMY
				BobSafeHouseRaid.Run_Script_Table.ENEMY = nil
			end
			if tostring(BobSafeHouseRaid.Run_Script_Table.POS):find('Vector3') then
				pos = BobSafeHouseRaid.Run_Script_Table.POS
				BobSafeHouseRaid.Run_Script_Table.POS = nil
			end
			if tostring(BobSafeHouseRaid.Run_Script_Table.ROT):find('Rotation') then
				rot = BobSafeHouseRaid.Run_Script_Table.ROT
				BobSafeHouseRaid.Run_Script_Table.ROT = nil
			end
		end
		local unit = safe_spawn_unit(enemy_name, pos, rot)
		unit:base():add_destroy_listener(self._unit_destroy_clbk_key, callback(self, self, "clbk_unit_destroyed"))
		unit:unit_data().mission_element = self
		local objective
		local action = self._create_action_data(CopActionAct._act_redirects.enemy_spawn[self._values.spawn_action])
		local stance = managers.groupai:state():enemy_weapons_hot() and "cbt" or "ntl"
		if action.type == "act" then
			objective = {
				type = "act",
				action = action,
				stance = stance
			}
		end
		local spawn_ai = {init_state = "idle", objective = objective}
		unit:brain():set_spawn_ai(spawn_ai)
		local team_id = params and params.team or self._values.team or tweak_data.levels:get_default_team_ID(unit:base():char_tweak().access == "gangster" and "gangster" or "combatant")
		if self._values.participate_to_group_ai then
			managers.groupai:state():assign_enemy_to_group_ai(unit, team_id)
		else
			managers.groupai:state():set_char_team(unit, team_id)
		end
		if self._values.voice then
			unit:sound():set_voice_prefix(self._values.voice)
		end
		table.insert(self._units, unit)
		self:event("spawn", unit)
		if self._values.force_pickup and self._values.force_pickup ~= "none" then
			local pickup_name = self._values.force_pickup ~= "no_pickup" and self._values.force_pickup or nil
			unit:character_damage():set_pickup(pickup_name)
		end
		return self._units[#self._units]
	else
		return OSHL_SpawnEnemyDummy(self, ...)
	end
end