if Network:is_client() then
	return
end

_G.BobSafeHouseRaid = _G.BobSafeHouseRaid or {}

local OSHL_init_orig = MissionManager.init
function MissionManager:init(...)
	OSHL_init_orig(self, ...)
	if Network:is_client() then
		return
	end
	if Global.game_settings and Global.game_settings.level_id == BobSafeHouseRaid.Level_ID and BobSafeHouseRaid then
		BobSafeHouseRaid.Enable = true
	else
		BobSafeHouseRaid.Enable = false
	end
end