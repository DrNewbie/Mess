if Network:is_client() then
	return
end

_G.BobSafeHouseRaid = _G.BobSafeHouseRaid or {}

BobSafeHouseRaid.Level_ID = "safehouse_survival_A"
BobSafeHouseRaid.Message2OtherPlayers = "This lobby is running 'Old Safe House Loud Mod'"
BobSafeHouseRaid.Message2WarnYou = "You're activating Safe House Loud MOD. \n You should only play with your friends."

BobSafeHouseRaid.Time2FirstSpawn = {
	normal = 60,
	hard = 60,
	overkill = 40,
	overkill_145 = 40,
	easy_wish = 40,
	overkill_290 = 30,
	sm_wish = 30
}
BobSafeHouseRaid.Time2RepeatSpawn = {
	normal = 20,
	hard = 20,
	overkill = 20,
	overkill_145 = 20,
	easy_wish = 20,
	overkill_290 = 20,
	sm_wish = 20
}
BobSafeHouseRaid.Time2RegenHealth = {
	normal = 10,
	hard = 10,
	overkill = 10,
	overkill_145 = 10,
	easy_wish = 10,
	overkill_290 = 10,
	sm_wish = 10
}
BobSafeHouseRaid.Time2OpenVault = {
	normal = 240,
	hard = 300,
	overkill = 300,
	overkill_145 = 420,
	easy_wish = 480,
	overkill_290 = 480,
	sm_wish = 540
}
BobSafeHouseRaid.Time2BobHealthRegenValues = {
	normal = 0.10,
	hard = 0.10,
	overkill = 0.05,
	overkill_145 = 0.05,
	easy_wish = 0.05,
	overkill_290 = 0.02,
	sm_wish = 0.02
}
BobSafeHouseRaid._Spawning = {
	normal = 2,
	hard = 2,
	overkill = 2,
	overkill_145 = 2,
	easy_wish = 2,
	overkill_290 = 3,
	sm_wish = 4
}
BobSafeHouseRaid._Spawning_Total = {
	normal = 70,
	hard = 80,
	overkill = 80,
	overkill_145 = 90,
	easy_wish = 90,
	overkill_290 = 100,
	sm_wish = 120
}
BobSafeHouseRaid._Spawning_Other_Total = {
	sniper = {
		normal = 5,
		hard = 5,
		overkill = 5,
		overkill_145 = 10,
		easy_wish = 10,
		overkill_290 = 20,
		sm_wish = 20
	},
	taser = {
		normal = 4,
		hard = 4,
		overkill = 4,
		overkill_145 = 10,
		easy_wish = 10,
		overkill_290 = 20,
		sm_wish = 20
	},
	shield = {
		easy = 10,
		normal = 20,
		hard = 20,
		overkill = 30,
		overkill_145 = 30,
		easy_wish = 30,
		overkill_290 = 30,
		sm_wish = 30
	},
	spooc = {
		normal = 2,
		hard = 2,
		overkill = 3,
		overkill_145 = 10,
		easy_wish = 10,
		overkill_290 = 20,
		sm_wish = 20
	},
	tank = {
		normal = 3,
		hard = 4,
		overkill = 5,
		overkill_145 = 10,
		easy_wish = 10,
		overkill_290 = 20,
		sm_wish = 20
	},
	medic = {
		easy = 10,
		normal = 20,
		hard = 20,
		overkill = 30,
		overkill_145 = 30,
		easy_wish = 30,
		overkill_290 = 30,
		sm_wish = 30
	}
}

BobSafeHouseRaid.Difficulty = Global.game_settings and Global.game_settings.difficulty or "normal"

local _D = BobSafeHouseRaid.Difficulty

BobSafeHouseRaid.Time4Use = {
	FirstSpawn = BobSafeHouseRaid.Time2FirstSpawn[_D],
	RepeatSpawn = BobSafeHouseRaid.Time2RepeatSpawn[_D],
	OpenVault = BobSafeHouseRaid.Time2OpenVault[_D],
	BobHealthRegenValues = BobSafeHouseRaid.Time2BobHealthRegenValues[_D],
	RegenHealth = BobSafeHouseRaid.Time2RegenHealth[_D]
}

BobSafeHouseRaid.Unit_Remove_When_Loud = {}

--Spawn_Settings
	local _default_enemy = {
		{ type = Idstring("units/payday2/characters/ene_fbi_heavy_1/ene_fbi_heavy_1"), amount = 3}				
	}
	if _D == "sm_wish" then
		_default_enemy = {
			{ type = Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy"), amount = 3}				
		}
	end
	BobSafeHouseRaid.Spawn_Settings = {}
	local Spawn_Settings = {}
	local Spawn_Settings_List = {}

	Spawn_Settings.default_group = {
		enemy = {
			normal = _default_enemy,
			hard = _default_enemy,
			overkill = _default_enemy,
			overkill_145 = _default_enemy,
			easy_wish = _default_enemy,
			overkill_290 = _default_enemy,
			sm_wish = _default_enemy
		}
	}
	table.insert(Spawn_Settings_List, "default_group")
	
	local _other_position = Spawn_Settings.default_group.position

	for i = 1, 9 do
		local _li = "other_00" .. i
		Spawn_Settings[_li] = deep_clone(Spawn_Settings.default_group)
		Spawn_Settings[_li].group_id = i+1
		Spawn_Settings[_li].position = _other_position
		Spawn_Settings[_li].POSNOADD = true
		table.insert(Spawn_Settings_List, _li)
	end
	
	
	BobSafeHouseRaid.Spawn_Settings = deep_clone(Spawn_Settings)
	BobSafeHouseRaid.Spawn_Settings_List = Spawn_Settings_List
	
	Spawn_Settings = {}
	Spawn_Settings_List = {}
	_default_enemy = {}

--Spawning_Other
	BobSafeHouseRaid.Spawning_Other = {
		sniper = {pos = BobSafeHouseRaid.Spawn_Settings.default_group.position},
		taser = {amount = 1, name = {Idstring("units/payday2/characters/ene_tazer_1/ene_tazer_1")}},
		shield = {amount = 3, name = {Idstring("units/payday2/characters/ene_shield_1/ene_shield_1")}},
		spooc = {amount = 1, name = {Idstring("units/payday2/characters/ene_spook_1/ene_spook_1")}},
		tank = {amount = 1, name = {Idstring("units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1")}},
		medic = {amount = 2, name = {Idstring("units/payday2/characters/ene_medic_m4/ene_medic_m4"), Idstring("units/payday2/characters/ene_medic_r870/ene_medic_r870")}},
		
		pos_default = {},
	}
	if _D ~= "easy" and _D ~= "normal" then
		table.insert(BobSafeHouseRaid.Spawning_Other.shield.name, Idstring("units/payday2/characters/ene_shield_2/ene_shield_2"))
		table.insert(BobSafeHouseRaid.Spawning_Other.tank.name, Idstring("units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2"))
	end
	if _D == "overkill_290" then
		table.insert(BobSafeHouseRaid.Spawning_Other.tank.name, Idstring("units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3"))
	end
	if _D == "sm_wish" then
		table.insert(BobSafeHouseRaid.Spawning_Other.spooc.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_cloaker/ene_zeal_cloaker"))
		table.insert(BobSafeHouseRaid.Spawning_Other.shield.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_swat_shield/ene_zeal_swat_shield"))
		table.insert(BobSafeHouseRaid.Spawning_Other.shield.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_swat_shield/ene_zeal_swat_shield"))
		table.insert(BobSafeHouseRaid.Spawning_Other.tank.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2/ene_zeal_bulldozer_2"))
		table.insert(BobSafeHouseRaid.Spawning_Other.tank.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3/ene_zeal_bulldozer_3"))
		table.insert(BobSafeHouseRaid.Spawning_Other.tank.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer/ene_zeal_bulldozer"))
	end
	_other_position = {}
	
function BobSafeHouseRaid:Announce(msg)
	managers.chat:send_message(ChatManager.GAME, "" , msg or "")
end

function BobSafeHouseRaid:_full_function_spawn(_name, _pos, _rot)
	local _poss = {
		--Behind_fence1~7
		100040, 100041, 100042, 100043, 100044, 100045, 100046,
		--outside_1~16
		100048, 100049, 100050, 100051, 100052, 100053, 100054, 100055, 100056,
		100057, 100058, 100059, 100060, 100061, 100062, 100063,
		--roof_1~7
		100064, 100065, 100066, 100067, 100103, 100104, 100105
	}
	local _id = _poss[math.random(#_poss)]
	self:Run_Script('', _id, _name, _pos, _rot)
end

function BobSafeHouseRaid:Spawn_Group(_R)
	local _S = {}
	_S = BobSafeHouseRaid.Spawn_Settings[_R] or {}
	if _S and _S.enemy then
		local _enemy = _S.enemy[_D] or {}
		if _enemy then
			for _, v in pairs(_enemy) do
				for j = 1, (v.amount or 0) do
					self:_full_function_spawn(v.type)
				end
			end
		end
	end
end

function BobSafeHouseRaid:Spawn_Other(data)
	World:spawn_unit(data.name, data.pos, data.rot)
end

BobSafeHouseRaid.Run_Script_Table = BobSafeHouseRaid.Run_Script_Table or {}

function BobSafeHouseRaid:Run_Script(editor_name, id, enemy, pos, rot)
	editor_name = editor_name or nil
	id = id or nil
	enemy = enemy or nil
	pos = pos or nil
	rot = rot or nil
	for _, script in pairs(managers.mission:scripts()) do
		for _id, _element in pairs(script:elements()) do
			local name = _element:editor_name()
			if (editor_name and name == editor_name) or (id and _id == id) then
				if enemy then
					self.Run_Script_Table.ENEMY = enemy
				end
				if pos then
					self.Run_Script_Table.POS = pos
				end
				if rot then
					self.Run_Script_Table.ROT = rot
				end
				_element:on_executed(managers.player:player_unit())
				return
			end
		end
	end
end