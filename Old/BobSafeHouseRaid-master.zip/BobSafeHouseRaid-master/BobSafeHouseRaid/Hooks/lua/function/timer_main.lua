if Network:is_client() then
	return
end

_G.BobSafeHouseRaid = _G.BobSafeHouseRaid or {}

local _D = BobSafeHouseRaid.Difficulty

BobSafeHouseRaid.Timer_Enable = false
BobSafeHouseRaid.Delay_Timer = 0
BobSafeHouseRaid.Go_Loud_Stage = 0
BobSafeHouseRaid.ForcedAssault = false
BobSafeHouseRaid.PhalanxBuff = false
BobSafeHouseRaid.MoneyBagEventBool = false
BobSafeHouseRaid.Timer_Main_Repeat_Dealy = 0
BobSafeHouseRaid.HealthAnnounce_Dealy = 0
BobSafeHouseRaid.HealthRegen_Dealy = 0
BobSafeHouseRaid.PROTECT_UNIT = nil
BobSafeHouseRaid.Loss_Win_Delay = 0
BobSafeHouseRaid.Loss_Win_Bool = false

Hooks:Add("GameSetupUpdate", "BobSafeHouseRaidGameSetupUpdate", function(t, dt)
	BobSafeHouseRaid:Timer_Main(t)
end)

function BobSafeHouseRaid:Timer_Main(t)
	if not Utils:IsInHeist() or self.Timer_Main_Repeat_Dealy > t then
		return
	end
	math.randomseed(tostring(os.time()):reverse():sub(1, 6))
	local _nowtime = math.floor(t)
	self.Timer_Main_Repeat_Dealy = _nowtime + 1
	local _start_time = self.Start_Time or 0
	--Mission start
	if self and self.Enable then
		--Init
		if not self.Timer_Enable and not managers.groupai:state():whisper_mode() then
			self.Timer_Enable = true
			self.Start_Time = _nowtime
			self.Delay_Timer = _nowtime + self.Time4Use.FirstSpawn
			self.Go_Loud_Stage = 1
			self.PROTECT_UNIT = World:spawn_unit(Idstring("units/payday2/characters/civ_male_casual_1/civ_male_casual_1"), Vector3(-1300, 2200, 0), Rotation(0, 0, 0))
			self.PROTECT_UNIT:movement():set_team(managers.groupai:state():team_data(tweak_data.levels:get_default_team_ID("combatant")))
			managers.groupai:state():convert_hostage_to_criminal(self.PROTECT_UNIT, _, true)
			self.PROTECT_UNIT:contour():add("friendly")
			self:Announce("[Hint] Protect Bobdozer!! Escape is coming in ".. self.Time4Use.OpenVault .." seconds")
			self.Timer_Main_Repeat_Dealy = _nowtime + 3
			return
		end
		local IsBobDead = false
		if self.PROTECT_UNIT and self.PROTECT_UNIT ~= nil and alive(self.PROTECT_UNIT) and self.PROTECT_UNIT.character_damage and not self.PROTECT_UNIT:character_damage():dead() then
			IsBobDead = false
		else
			IsBobDead = true
		end
		--RIP Bob , LOSS
		if IsBobDead and self.Loss_Win_Delay == 0 then
			self.Loss_Win_Delay = _nowtime + 3
			self.Loss_Win_Bool = false
			self:Announce("\t[System] Bobdozer died!!\t")
			return
		end
		if self.Loss_Win_Delay > 0 and _nowtime > self.Loss_Win_Delay then
			if not self.Loss_Win_Bool then
				managers.network:session():send_to_peers("mission_ended", false, 0)
				game_state_machine:change_state_by_name("gameoverscreen")
			else
				local num_winners = managers.network:session():amount_of_alive_players()
				managers.network:session():send_to_peers("mission_ended", true, num_winners)
				game_state_machine:change_state_by_name("victoryscreen", {
					num_winners = num_winners,
					personal_win = alive(managers.player:player_unit())
				})
			end
			return
		end
		--Bob , Health Regen
		if not IsBobDead and _nowtime > self.HealthRegen_Dealy then
			self.HealthRegen_Dealy = _nowtime + self.Time4Use.RegenHealth
			local _HEALTH_INIT = self.PROTECT_UNIT:character_damage()._HEALTH_INIT
			self.PROTECT_UNIT:character_damage()._health = self.PROTECT_UNIT:character_damage()._health + (_HEALTH_INIT)*(BobSafeHouseRaid.Time4Use.BobHealthRegenValues)
			self.PROTECT_UNIT:character_damage()._health = math.clamp(self.PROTECT_UNIT:character_damage()._health, 0, _HEALTH_INIT)
			self.PROTECT_UNIT:character_damage()._health_ratio = math.clamp((self.PROTECT_UNIT:character_damage()._health)/(_HEALTH_INIT), 0, 1)
		end
		--Go loud
		if self.Timer_Enable and self.Delay_Timer < _nowtime and self.Go_Loud_Stage == 1 then
			--Bob Health Announce
			if not IsBobDead and _nowtime > self.HealthAnnounce_Dealy then
				local health_ratio = math.clamp(math.round(self.PROTECT_UNIT:character_damage():health_ratio()*100), 0, 100)
				local loss_health_ratio = math.clamp(100 - health_ratio, 0, 100)
				if health_ratio >= 75 then
					self.HealthAnnounce_Dealy = _nowtime + 50
				elseif health_ratio >= 50 and health_ratio < 75 then
					self.HealthAnnounce_Dealy = _nowtime + 40
				elseif health_ratio >= 25 and health_ratio < 50 then
					self.HealthAnnounce_Dealy = _nowtime + 30
				else
					self.HealthAnnounce_Dealy = _nowtime + 20
				end
				self:Announce("[Hint] Bobdozer Health Ratio:".. health_ratio .."/%")
			end
			self.Delay_Timer = self.Time4Use.RepeatSpawn + _nowtime
			if not self.ForcedAssault and _nowtime - self.Start_Time > 10 then
				self.ForcedAssault = true
				managers.groupai:state():on_police_called("alarm_pager_hang_up")
				managers.groupai:state():special_assault_function()
				managers.groupai:state():set_assault_endless(true)
				--Reducebuff
				managers.network:session():send_to_peers_synched("sync_damage_reduction_buff", 0.5)
				managers.groupai:state():set_phalanx_damage_reduction_buff(0.5)
				managers.groupai:state():set_damage_reduction_buff_hud()
			end
			if not IsBobDead and self.Loss_Win_Delay == 0 and _nowtime - self.Start_Time > self.Time4Use.OpenVault then
				self.Loss_Win_Delay = _nowtime + 3
				self.Loss_Win_Bool = true
				self:Announce("\t[System] Time to escape!!\t")
				return
			end
			--Spawn
			local _all_enemies = managers.enemy:all_enemies() or {}
			local _Spawning = self._Spawning or {}
			local _Spawning_Total = self._Spawning_Total or {}
			local _T = table.size(self.Spawn_Settings_List)
			local _C = _Spawning[_D]
			local _total_enemies = table.size(_all_enemies)
			local _enemy_type_amount = {}
			for _, data in pairs(_all_enemies) do
				local enemyType = tostring(data.unit:base()._tweak_table)
				if not _enemy_type_amount[enemyType] then
					_enemy_type_amount[enemyType] = 1
				else
					_enemy_type_amount[enemyType] = _enemy_type_amount[enemyType] + 1
				end
			end
			if _total_enemies < _Spawning_Total[_D] then
				local _Last_R
				for i = 1, _C do
					local _R = self.Spawn_Settings_List[math.random(_T)]
					if _Last_R ~= _R then
						_Last_R = _R
						self:Spawn_Group(_R)
					else
						_C = _C + 1
					end
				end
			end
			if not _enemy_type_amount["sniper"] then
				_enemy_type_amount["sniper"] = 0
			end
			if _enemy_type_amount["sniper"] < self._Spawning_Other_Total["sniper"][_D] then
				self:_full_function_spawn(Idstring("units/payday2/characters/ene_sniper_2/ene_sniper_2"))
			end
			local _other = {
				taser = self.Spawning_Other.taser,
				shield = self.Spawning_Other.shield,
				spooc = self.Spawning_Other.spooc,
				tank = self.Spawning_Other.tank,
				medic = self.Spawning_Other.medic				
			}						
			local _list
			for _type, _data in pairs(_other) do
				_type = tostring(_type)
				_list = _data.name
				if not _enemy_type_amount[_type] then
					_enemy_type_amount[_type] = 0
				end
				if _enemy_type_amount[_type] < self._Spawning_Other_Total[_type][_D] then
					for i = 1, _data.amount do
						self:_full_function_spawn(_list[math.random(#_list)])
					end
				end
			end
		end
	end
end