_G.AutoTranslator = _G.AutoTranslator or {}

if not AutoTranslator then
	return	
end

local _sl = "auto"

function url_encode(str)
	if (str) then
		str = string.gsub (str, "\n", "\r\n")
		str = string.gsub (str, "([^%w %-%_%.%~])",
			function (c) return string.format ("%%%02X", string.byte(c)) end)
		str = string.gsub (str, " ", "+")
	end
	return str
end

function lookupTranslation(channel_id, name, msg, color, icon)
	local _tl = "en"
	local _select = tonumber(AutoTranslator.settings.Language) or 1
	local _list = AutoTranslator.list_of_possible or {}
	if _list and _list[_select] and _list[_select][1] then
		_tl = _list[_select][1]
	end
	msg = url_encode(msg)
	dohttpreq("https://translate.googleapis.com/translate_a/single?client=gtx&ie=utf-8&sl=".. _sl .."&tl=".. _tl .."&dt=t&text=" .. msg, function(data)
		if data and json then
			data = data:gsub(",,", ",")
			data = data:gsub(",,", ",")
			data = json.decode(data) or {}
			if data[1] and data[1][1] and data[1][1][1] and data[2] and data[2] ~= _tl and not AutoTranslator.no_translate[data[2]] then
				managers.chat:_receive_message(channel_id, name, "(" .. data[1][1][1] .. ")", color, icon, true)
			end
		end
	end)
end

function ChatManager:_receive_message(channel_id, name, message, color, icon, notagain)
	if not self._receivers[channel_id] then
		return
	end
	for i, receiver in ipairs(self._receivers[channel_id]) do
		receiver:receive_message(name, message, color, icon)
	end
	if not notagain then
		lookupTranslation(channel_id, name, message, color, icon)
	end
end