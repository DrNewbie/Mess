local _missino_init_orig = MissionManager.init
function MissionManager:init(...)
	_missino_init_orig(self, ...)
	if not PackageManager:loaded("packages/narr_jerry1") then
		PackageManager:load("packages/narr_jerry1")
	end
	if not PackageManager:loaded("levels/narratives/pbr/berry/world_sounds") then
		PackageManager:load("levels/narratives/pbr/berry/world_sounds")
	end
	if not PackageManager:loaded("levels/narratives/pbr/jerry/world_sounds") then
		PackageManager:load("levels/narratives/pbr/jerry/world_sounds")
	end
end