local init = PlayerBase.init
function PlayerBase:init(unit)
	init(self, unit)
	managers.player.locke:spawn_unit(unit)
end
local pre_destroy = PlayerBase.pre_destroy
function PlayerBase:pre_destroy(unit)
	pre_destroy(self, unit)
	managers.player.locke:delete_unit()
end
