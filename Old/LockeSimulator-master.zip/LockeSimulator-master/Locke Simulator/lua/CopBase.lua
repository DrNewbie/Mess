local LockeSimulator_CopBasedefault_weapon_name = CopBase.default_weapon_name

function CopBase:default_weapon_name(...)
	if self._unit and alive(self._unit) and self._unit:name():key() == "a98a3f0bf26eb52f" and not managers.player.locke:unit_alive() then
		return Idstring("units/payday2/weapons/wpn_npc_lmg_m249/wpn_npc_lmg_m249")	
	end
	return LockeSimulator_CopBasedefault_weapon_name(self, ...)
end