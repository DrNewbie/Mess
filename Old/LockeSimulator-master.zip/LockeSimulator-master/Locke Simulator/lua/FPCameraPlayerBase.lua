function FPCameraPlayerBase:set_position(pos)
	self._unit:set_position(Vector3(0,0,-100000))
end