function UnitNetworkHandler:sync_contour_state(unit, u_id, type, state, multiplier, sender)
	return
end