local _SimulatorCompatible_ContourExt_add = ContourExt.add

function ContourExt:add(type, sync, multiplier)
	if type == "mark_enemy_damage_bonus" or type == "mark_enemy" then
		return
	end
	_SimulatorCompatible_ContourExt_add(self, type, sync, multiplier)
end