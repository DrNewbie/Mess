local _SimulatorCompatible_LocalizationManager_text = LocalizationManager.text

function LocalizationManager:text(string_id, macros)
	if tostring(string_id) == "nil" then
		return " "
	end
	return _SimulatorCompatible_LocalizationManager_text(self, string_id, macros)
end