function _LockeSimulator_Damage_Fixed(damage)
	return damage * 1.1
end

local _SimulatorCompatible_CopDamage_damage_melee = CopDamage.damage_melee
function CopDamage:damage_melee(attack_data)
	if self._unit == managers.player.locke:unit() and managers.player.locke:parent() then
		attack_data.damage = _LockeSimulator_Damage_Fixed(attack_data.damage)
		managers.player.locke:parent():character_damage():damage_melee(attack_data)
		return
	end
	return _SimulatorCompatible_CopDamage_damage_melee(self, attack_data)
end

local _SimulatorCompatible_CopDamage_damage_explosion = CopDamage.damage_explosion
function CopDamage:damage_explosion(attack_data)
	if self._unit == managers.player.locke:unit() and managers.player.locke:parent() then
		attack_data.damage = _LockeSimulator_Damage_Fixed(attack_data.damage)
		managers.player.locke:parent():character_damage():damage_explosion(attack_data)
		return
	end
	return _SimulatorCompatible_CopDamage_damage_explosion(self, attack_data)
end

local _SimulatorCompatible_CopDamage_damage_fire = CopDamage.damage_fire
function CopDamage:damage_fire(attack_data)
	if self._unit == managers.player.locke:unit() and managers.player.locke:parent() then
		attack_data.damage = _LockeSimulator_Damage_Fixed(attack_data.damage)
		managers.player.locke:parent():character_damage():damage_fire(attack_data)
		return
	end
	return _SimulatorCompatible_CopDamage_damage_fire(self, attack_data)
end

function CopDamage:damage_tase(attack_data)
end

local _SimulatorCompatible_CopDamage_damage_bullet = CopDamage.damage_bullet
function CopDamage:damage_bullet(attack_data)
	if self._unit == managers.player.locke:unit() and managers.player.locke:parent() then
		attack_data.damage = _LockeSimulator_Damage_Fixed(attack_data.damage)
		managers.player.locke:parent():character_damage():damage_bullet(attack_data)
		return
	end
	return _SimulatorCompatible_CopDamage_damage_bullet(self, attack_data)
end

local _SimulatorCompatible_CopDamage_damage_killzone = CopDamage.damage_killzone
function CopDamage:damage_killzone(attack_data)
	if self._unit == managers.player.locke:unit() and managers.player.locke:parent() then
		attack_data.damage = _LockeSimulator_Damage_Fixed(attack_data.damage)
		managers.player.locke:parent():character_damage():damage_killzone(attack_data)
		return
	end
	return _SimulatorCompatible_CopDamage_damage_killzone(self, attack_data)
end