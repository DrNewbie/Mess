
-- This should completely disable saving of the savegame
function SavefileManager:_save(slot, cache_only, save_system, ...)
	return
end
