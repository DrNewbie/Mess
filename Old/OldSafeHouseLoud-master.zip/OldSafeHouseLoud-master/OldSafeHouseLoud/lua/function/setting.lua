if Network:is_client() then
	return
end

_G.ShadowRaidLoud = _G.ShadowRaidLoud or {}

ShadowRaidLoud.Level_ID = "safehouse"
ShadowRaidLoud.Message2OtherPlayers = "This lobby is running 'Old Safe House Loud Mod'"
ShadowRaidLoud.Message2WarnYou = "You're activating Safe House Loud MOD. \n You should only play with your friends."

ShadowRaidLoud.Time2FirstSpawn = {
	normal = 60,
	hard = 60,
	overkill = 40,
	overkill_145 = 40,
	easy_wish = 40,
	overkill_290 = 30,
	sm_wish = 30
}
ShadowRaidLoud.Time2RepeatSpawn = {
	normal = 20,
	hard = 20,
	overkill = 20,
	overkill_145 = 20,
	easy_wish = 20,
	overkill_290 = 20,
	sm_wish = 20
}
ShadowRaidLoud.Time2OpenVault = {
	normal = 120,
	hard = 160,
	overkill = 200,
	overkill_145 = 240,
	easy_wish = 240,
	overkill_290 = 300,
	sm_wish = 300
}
ShadowRaidLoud._Spawning = {
	normal = 2,
	hard = 2,
	overkill = 2,
	overkill_145 = 2,
	easy_wish = 2,
	overkill_290 = 2,
	sm_wish = 2
}
ShadowRaidLoud._Spawning_Total = {
	normal = 50,
	hard = 60,
	overkill = 60,
	overkill_145 = 70,
	easy_wish = 70,
	overkill_290 = 70,
	sm_wish = 70
}
ShadowRaidLoud._Spawning_Other_Total = {
	sniper = {
		normal = 5,
		hard = 5,
		overkill = 5,
		overkill_145 = 5,
		easy_wish = 5,
		overkill_290 = 5,
		sm_wish = 5
	},
	taser = {
		normal = 4,
		hard = 4,
		overkill = 4,
		overkill_145 = 6,
		easy_wish = 6,
		overkill_290 = 6,
		sm_wish = 6
	},
	shield = {
		easy = 10,
		normal = 20,
		hard = 20,
		overkill = 30,
		overkill_145 = 30,
		easy_wish = 30,
		overkill_290 = 30,
		sm_wish = 30
	},
	spooc = {
		normal = 2,
		hard = 2,
		overkill = 3,
		overkill_145 = 4,
		easy_wish = 4,
		overkill_290 = 5,
		sm_wish = 5
	},
	tank = {
		normal = 3,
		hard = 4,
		overkill = 5,
		overkill_145 = 6,
		easy_wish = 6,
		overkill_290 = 8,
		sm_wish = 8
	}
}

ShadowRaidLoud.Difficulty = Global.game_settings and Global.game_settings.difficulty or "normal"

local _D = ShadowRaidLoud.Difficulty

ShadowRaidLoud.Time4Use = {
	FirstSpawn = ShadowRaidLoud.Time2FirstSpawn[_D],
	RepeatSpawn = ShadowRaidLoud.Time2RepeatSpawn[_D],
	OpenVault = ShadowRaidLoud.Time2OpenVault[_D],
}

ShadowRaidLoud.Unit_Remove_When_Loud = {
	{ key = "673ea142d68175df", position = { Vector3(0, 0, 0) } },
	{ key = "86efb80bf784046f", position = { Vector3(0, 0, 0) } },
	{ key = "b37a4188fde4c161", position = { Vector3(0, 0, 0) } },
	{ key = "7ae8fcbfe6a00f7b", position = { Vector3(0, 0, 0) } },
	{ key = "c5c4442c5e147cb0", position = { Vector3(0, 0, 0) } },
	{ key = "8f3cb89b79b42ec4", position = { Vector3(0, 0, 0) } },
	{ key = "e8fe662bb4d262d3", position = { Vector3(0, 0, 0) } },
	{ key = "9d8b22836aa015ed", position = { Vector3(0, 0, 0) } },
	{ key = "63be2c801283f573", position = { Vector3(0, 0, 0) } },
	{ key = "78f4407343b48f6d", position = { Vector3(0, 0, 0) } },
	{ key = "29d0139549a54de7", position = { Vector3(0, 0, 0) } },
	{ key = "e379cc9592197cd8", position = { Vector3(0, 0, 0) } },
	{ key = "7a4c85917d8d8323", position = { Vector3(0, 0, 0) } },
	{ key = "9eda9e73ac0ef710", position = { Vector3(0, 0, 0) } },
	{ key = "276de19dc5541f30", position = { Vector3(0, 0, 0) } },
	{ key = "6cdb4f6f58ec4fa8", position = { Vector3(0, 0, 0) } },
	{ key = "88ccbf0557c76d6e", position = { Vector3(0, 0, 0) } },
	{ key = "9c5716b1233940a7", position = { Vector3(0, 0, 0) } }	
}

--Spawn_Settings
	local _default_enemy = {
		{ type = "units/payday2/characters/ene_fbi_heavy_1/ene_fbi_heavy_1", amount = 3}				
	}
	if _D == "sm_wish" then
		_default_enemy = {
			{ type = "units/pd2_dlc_gitgud/characters/ene_zeal_swat_heavy/ene_zeal_swat_heavy", amount = 3}				
		}
	end
	ShadowRaidLoud.Spawn_Settings = {}
	local Spawn_Settings = {}
	local Spawn_Settings_List = {}

	Spawn_Settings.default_group = {
		group_id = 1,
		position = {Vector3(-3268.29, 4351.94, 1.1), Vector3(-4789.37, 1080.14, 1.10039), Vector3(-3317.1, 1023, 1.1001), Vector3(-1825.59, 4585.59, 1.10001), Vector3(-3629.49, 3373.36, 1.10001)},
		rotation = {Rotation(0, 0, 1)},
		enemy = { normal = _default_enemy,
				hard = _default_enemy,
				overkill = _default_enemy,
				overkill_145 = _default_enemy,
				overkill_290 = _default_enemy},
	}
	table.insert(Spawn_Settings_List, "default_group")
	
	local _other_position = Spawn_Settings.default_group.position

	for i = 1, 9 do
		local _li = "other_00" .. i
		Spawn_Settings[_li] = deep_clone(Spawn_Settings.default_group)
		Spawn_Settings[_li].group_id = i+1
		Spawn_Settings[_li].position = _other_position
		Spawn_Settings[_li].POSNOADD = true
		table.insert(Spawn_Settings_List, _li)
	end
	
	
	ShadowRaidLoud.Spawn_Settings = deep_clone(Spawn_Settings)
	ShadowRaidLoud.Spawn_Settings_List = Spawn_Settings_List
	
	Spawn_Settings = {}
	Spawn_Settings_List = {}
	_default_enemy = {}

--Spawning_Other
	ShadowRaidLoud.Spawning_Other = {
		sniper = {pos = ShadowRaidLoud.Spawn_Settings.default_group.position},
		taser = {amount = 1, name = {Idstring("units/payday2/characters/ene_tazer_1/ene_tazer_1")}},
		shield = {amount = 3, name = {Idstring("units/payday2/characters/ene_shield_1/ene_shield_1")}},
		spooc = {amount = 1, name = {Idstring("units/payday2/characters/ene_spook_1/ene_spook_1")}},
		tank = {amount = 1, name = {Idstring("units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1")}},
		
		pos_default = {},
	}
	if _D ~= "easy" and _D ~= "normal" then
		table.insert(ShadowRaidLoud.Spawning_Other.shield.name, Idstring("units/payday2/characters/ene_shield_2/ene_shield_2"))
		table.insert(ShadowRaidLoud.Spawning_Other.tank.name, Idstring("units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2"))
	end
	if _D == "overkill_290" then
		table.insert(ShadowRaidLoud.Spawning_Other.tank.name, Idstring("units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3"))
	end
	if _D == "sm_wish" then
		table.insert(ShadowRaidLoud.Spawning_Other.spooc.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_cloaker/ene_zeal_cloaker"))
		table.insert(ShadowRaidLoud.Spawning_Other.shield.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_swat_shield/ene_zeal_swat_shield"))
		table.insert(ShadowRaidLoud.Spawning_Other.shield.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_swat_shield/ene_zeal_swat_shield"))
		table.insert(ShadowRaidLoud.Spawning_Other.tank.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_2/ene_zeal_bulldozer_2"))
		table.insert(ShadowRaidLoud.Spawning_Other.tank.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer_3/ene_zeal_bulldozer_3"))
		table.insert(ShadowRaidLoud.Spawning_Other.tank.name, Idstring("units/pd2_dlc_gitgud/characters/ene_zeal_bulldozer/ene_zeal_bulldozer"))
	end
	for _, v in pairs(ShadowRaidLoud.Spawn_Settings) do
		if not v.POSNOADD then
			table.insert(ShadowRaidLoud.Spawning_Other.pos_default, v.position[1])
		end
	end	
	
	for _, v in pairs(_other_position) do
		table.insert(ShadowRaidLoud.Spawning_Other.pos_default, v)
	end
	
	_other_position = {}
	
function ShadowRaidLoud:Announce(msg)
	managers.chat:send_message(ChatManager.GAME, "" , msg or "")
end

function set_team(unit)
	local team = unit:base():char_tweak().access == "gangster" and "gangster" or "combatant"
	local AIState = managers.groupai:state()
	local team_id = tweak_data.levels:get_default_team_ID(team)
	unit:movement():set_team(AIState:team_data(team_id))
end

function ShadowRaidLoud:_full_function_spawn(name, pos, rot, delay)
	delay = delay or 1
	local _nowslot = math.random(1, 100)
	DelayedCalls:Add("DelayedCalls_ShadowRaidLoud_full_function_spawn_" .. _nowslot, delay, function()
		local _player_unit = {}
		for _, data in pairs(managers.groupai:state():all_criminals() or {}) do
			table.insert(_player_unit, data.unit)
		end
		local _final_unit_to_use = _player_unit[math.random(table.size(_player_unit))] or {}
		local new_objective = {
			type = "follow",
			follow_unit = _final_unit_to_use,
			called = true,
			destroy_clbk_key = false,
			scan = true
		}
		pos = pos + Vector3(0, 0, 10)
		local _u = World:spawn_unit(name, pos, rot)
		set_team(_u)
		_u:brain():set_spawn_ai( { init_state = "idle", params = { scan = true }, objective = new_objective } )
		_u:movement():set_character_anim_variables()
	end)
end

function ShadowRaidLoud:Spawn_Other(data)
	World:spawn_unit(data.name, data.pos, data.rot)
end

function ShadowRaidLoud:Run_Script(editor_name)
	for _, script in pairs(managers.mission:scripts()) do
		for _,element in pairs(script:elements()) do
			local name = element:editor_name()
			if name == editor_name then
				element:on_executed(managers.player:player_unit())
				return
			end
		end
	end
end

function ShadowRaidLoud:MoneyBagEventDone(run)
	if run == 0 then
		DelayedCalls:Add("DelayedCalls_ShadowRaidLoud_MoneyBagEventDone", 1, function()
			managers.loot:secure("money", 1)
			managers.loot:_check_triggers("report_only")
		end)
		DelayedCalls:Add("DelayedCalls_ShadowRaidLoud_MoneyBagEventRepeat", ShadowRaidLoud.Time4Use.OpenVault, function()
			ShadowRaidLoud._run["100850"] = false
			ShadowRaidLoud._run["100800"] = false
			ShadowRaidLoud:Run_Script("moneybagobjective")
			managers.chat:send_message(ChatManager.GAME, "" , "[System] Bag is ready to spawn, go get it.")
		end)
	end
	if run == 1 then
		DelayedCalls:Add("DelayedCalls_ShadowRaidLoud_Win", 1, function()
			local num_winners = managers.network:session():amount_of_alive_players()
			managers.network:session():send_to_peers("mission_ended", true, num_winners)
			game_state_machine:change_state_by_name("victoryscreen", {num_winners = num_winners, personal_win = true})
		end)
	end
end