core:import("CoreMissionScriptElement")
ElementLootBag = ElementLootBag or class(CoreMissionScriptElement.MissionScriptElement)

_G.ShadowRaidLoud = _G.ShadowRaidLoud or {}
ShadowRaidLoud = _G.ShadowRaidLoud

if not ShadowRaidLoud then
	return
end

if Network:is_client() then
	return
end

ShadowRaidLoud._run = ShadowRaidLoud._run or {}

local _f_ElementLootBag_on_executed = ElementLootBag.on_executed

function ElementLootBag:on_executed(...)
	local _id = tostring(self._id)
	if _id == "100800" then
		if ShadowRaidLoud._run[_id] then
			return
		end
		ShadowRaidLoud._run[_id] = true
	end
	_f_ElementLootBag_on_executed(self, ...)
end