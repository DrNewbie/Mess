if Network:is_client() then
	return
end

_G.ShadowRaidLoud = _G.ShadowRaidLoud or {}

function ShadowRaidLoud_CopBrain_path_change(them, to_pos)
	local enemyType = tostring(them._unit:base()._tweak_table)
	if ( enemyType ~= "security" and enemyType ~= "gensec" and
		enemyType ~= "cop" and enemyType ~= "fbi" and
		enemyType ~= "swat" and enemyType ~= "heavy_swat" and
		enemyType ~= "fbi_swat" and enemyType ~= "fbi_heavy_swat" and
		enemyType ~= "city_swat" and enemyType ~= "sniper" and
		enemyType ~= "gangster" and enemyType ~= "taser" and
		enemyType ~= "tank" and enemyType ~= "spooc" and enemyType ~= "shield" ) or not ShadowRaidLoud or not ShadowRaidLoud.Timer_Enable then
		return to_pos
	end
	local _now_time = math.floor(TimerManager:game():time())
	if them and not them._go_to_special_target_unit then
		them._go_to_special_target_unit = 0
	end
	if them and them._special_target_unit and alive(them._special_target_unit) and them._special_target_unit:position() then
		if math.random(1, 3) >= 2 or them._go_to_special_target_unit > _now_time then
			local _xy_fixd = {50, -50, 0}
			to_pos = them._special_target_unit:position() + Vector3(_xy_fixd[math.random(1, 3)], _xy_fixd[math.random(1, 3)], 0)
			if them._go_to_special_target_unit <= _now_time then
				them._go_to_special_target_unit = _now_time + 30
			end
		end
	else
		local _player_unit = {}
		for _, data in pairs(managers.groupai:state():all_criminals() or {}) do
			table.insert(_player_unit, data.unit)
		end
		if _player_unit and #_player_unit > 0 then
			local _special_target_unit = _player_unit[math.random(#_player_unit)]
			them._special_target_unit = _special_target_unit
		end
	end
	return to_pos
end

local _ShadowRaidLoud_CopBrain_search_for_path = CopBrain.search_for_path

function CopBrain:search_for_path(search_id, to_pos, ...)
	to_pos = ShadowRaidLoud_CopBrain_path_change(self, to_pos)
	return _ShadowRaidLoud_CopBrain_search_for_path(self, search_id, to_pos, ...)
end