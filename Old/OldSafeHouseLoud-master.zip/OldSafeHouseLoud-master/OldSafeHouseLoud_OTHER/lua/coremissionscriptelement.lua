core:module("CoreMissionScriptElement")
core:import("CoreXml")
core:import("CoreCode")
core:import("CoreClass")

_G.ShadowRaidLoud = _G.ShadowRaidLoud or {}
ShadowRaidLoud = _G.ShadowRaidLoud

if not ShadowRaidLoud then
	return
end

if Network:is_client() then
	return
end

ShadowRaidLoud._run = ShadowRaidLoud._run or {}

local _f_MissionScriptElement_on_executed = MissionScriptElement.on_executed

function MissionScriptElement:on_executed(...)
	local _id = tostring(self._id)
	if ShadowRaidLoud and ShadowRaidLoud.Enable then
		if _id == "100850" and not ShadowRaidLoud._run[_id] then
			ShadowRaidLoud._run[_id] = true
			ShadowRaidLoud:MoneyBagEventDone(0)
		end
		if _id == "100537" and not ShadowRaidLoud._run[_id] then
			ShadowRaidLoud._run[_id] = true
			ShadowRaidLoud:MoneyBagEventDone(1)
		end
		if _id == "100319" and not ShadowRaidLoud._run[_id] then
			ShadowRaidLoud._run[_id] = true
			local _name = Idstring("units/payday2/equipment/gen_interactable_door_vault_light/gen_interactable_door_vault_light")
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-1090, 2800, -30), rot = Rotation(0, 90, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-1000, 2200, 2), rot = Rotation(90, 0, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2930, 1960, 1), rot = Rotation(0, 0, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2340, 1960, 1), rot = Rotation(0, 0, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2640, 1960, 1), rot = Rotation(0, 0, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2930, 1960, 290), rot = Rotation(0, 60, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2340, 1960, 290), rot = Rotation(0, 60, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2640, 1960, 290), rot = Rotation(0, 60, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2470, 2725, 1), rot = Rotation(180, 0, 0), name = _name})
			ShadowRaidLoud:Spawn_Other({ pos = Vector3(-2810, 2725, 1), rot = Rotation(180, 0, 0), name = _name})
		end
	end
	_f_MissionScriptElement_on_executed(self, ...)
end