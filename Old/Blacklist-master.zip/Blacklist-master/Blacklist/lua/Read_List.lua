_G.BlackList = _G.BlackList or {}

BlackList.Ban_list_SteamID64 = BlackList.Ban_list_SteamID64 or {}
BlackList.ModPath = BlackList.ModPath or ModPath
BlackList.Old_Name = BlackList.Old_Name or {}
BlackList.Old_Steam = BlackList.Old_Steam or {}

function BlackList:RefreshList(_cleanall)
	if not _G or not _G.BlackList or not BlackList then
		return
	end
	if _cleanall then
		BlackList.Ban_list_SteamID64 = {}
		BlackList.Old_Name = {}
		BlackList.Old_Steam = {}
	end
	local _file, err = io.open("kicklist.ini", "r")
	if not _file then
		return
	end	
	local line = _file:read()
	local _txt = tostring(line)
	local count = 0
	while line do
		count = count + 1
		if not BlackList.Ban_list_SteamID64[_txt] then
			BlackList.Ban_list_SteamID64[_txt] = count
		end
		line = _file:read()
		_txt = tostring(line)
	end	
	_file:close()
end

function BlackList:WriteIntoList(data)
	if data == nil or not data then
		return
	end
	local _file = io.open("kicklist.ini", "a")
	if not _file then
		return false
	end
	_file:write("" .. data, "\n")
	_file:close()
	BlackList:RefreshList(false)
	local feed_get = "[BlackList]: ADD NEW ID: " .. data .. ""
	log(feed_get)
	managers.chat:feed_system_message(ChatManager.GAME, feed_get, "")
	if managers.hud and managers.network then
		local peers = managers.network:session():peers() or {}
		local reason = ""
		local _txt = ""
		for k, v in pairs(peers) do
			if v then
				_txt = tostring(v:user_id())
			end
			if BlackList.Ban_list_SteamID64[_txt] then
				reason = v:name() .. " is in your Blacklist"
				managers.chat:feed_system_message(ChatManager.GAME, reason, ""	)
				managers.hud:mark_cheater(v:id())
			end
		end
	end
end

function BlackList:format_time(timestamp, format, tzoffset, tzname)
	if tzoffset == "local" then  -- calculate local time zone (for the server)
		local now = os.time()
		local local_t = os.date("*t", now)
		local utc_t = os.date("!*t", now)
		local delta = (local_t.hour - utc_t.hour)*60 + (local_t.min - utc_t.min)
		local h, m = math.modf( delta / 60)
		tzoffset = string.format("%+.4d", 100 * h + 60 * m)
	end
	tzoffset = tzoffset or "GMT"
	format = format:gsub("%%z", tzname or tzoffset)
	if tzoffset == "GMT" then
		tzoffset = "+0000"
	end
	tzoffset = tzoffset:gsub(":", "")

	local sign = 1
	if tzoffset:sub(1,1) == "-" then
		sign = -1
		tzoffset = tzoffset:sub(2)
	elseif tzoffset:sub(1,1) == "+" then
		tzoffset = tzoffset:sub(2)
	end
	tzoffset = sign * (tonumber(tzoffset:sub(1,2))*60 + tonumber(tzoffset:sub(3,4)))*60
	return os.date(format, timestamp + tzoffset)
end

function BlackList:Record_History(peer_id)
	if not managers.network or not managers.network:session() then
		log("[BlackList]: Record_History \t not managers.network")
		return
	end
	local peer_now = managers.network:session():peer(peer_id)
	if not peer_now then
		log("[BlackList]: Record_History \t no peer_now")
		return
	end
	if peer_now == managers.network:session():local_peer() then
		log("[BlackList]: Record_History \t peer_now == local_peer")
		return
	end
	local _steam_id64 = tostring(peer_now:user_id())
	local _name = tostring(peer_now:name())
	if BlackList.Ban_list_SteamID64 and BlackList.Ban_list_SteamID64[_steam_id64] then
		if managers.chat then
			managers.chat:feed_system_message(ChatManager.GAME, "'" .._name .. "' [".. _steam_id64 .."] is in your Blacklist", "")
		end
		if managers.hud then
			managers.hud:mark_cheater(peer_id)
		end
	end
	local _level_id = managers.job:has_active_job() and managers.job:current_level_id() or ""
	if _level_id and _level_id ~= "" then
		local _level_name_id = tweak_data.levels[_level_id] and tweak_data.levels[_level_id].name_id
		local _level_name = _level_name_id and managers.localization:text(_level_name_id) or "LEVEL NAME ERROR"
		local _now_time = BlackList:format_time(os.time(), "!%H:%M:%S %z", "local")
		local _record = "\n{".. tostring(json.encode({Player = _name})) ..",\t".. tostring(json.encode({SteamID64 = _steam_id64})) ..",\t".. tostring(json.encode({Is_Host = peer_now:is_host()})) ..",\t".. tostring(json.encode({Time = _now_time})) ..",\t".. tostring(json.encode({Heist = _level_name})) .."}\n"
		local _file = io.open(BlackList.ModPath .. "/history.txt", "a")
		if _file then
			_file:write("" .. _record, "\n")							
			_file:close()
			log("[BlackList]: Record_History \t ".._record)
		end
	end
end

function BlackList:Record_All()
	local _dt = 0
	for peer_id, _ in pairs(managers.network:session():peers()) do
		_dt = _dt + 1
		DelayedCalls:Add('DelayedModBlackListZ_' .. tostring(peer_id), 1 + _dt, function()
			BlackList:Record_History(peer_id)
		end)
	end
end

BlackList:RefreshList(true)