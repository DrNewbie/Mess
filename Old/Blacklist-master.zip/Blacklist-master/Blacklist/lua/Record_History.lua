_G.BlackList = _G.BlackList or {}

if HostNetworkSession then
	Hooks:PostHook(HostNetworkSession, 'on_peer_entered_lobby', 'F_'..Idstring('BlackList:HostNetworkSessionOnPeerEnteredLobby'):key(), function(self, peer)
		local peer_id = peer:id()
		DelayedCalls:Add('DelayedModBlackListX_' .. tostring(peer_id), 1, function()
			BlackList:Record_History(peer_id)
		end)
	end)

	Hooks:PostHook(HostNetworkSession, 'on_peer_sync_complete', 'F_'..Idstring('BlackList:HostNetworkSessionOnPeerSyncComplete'):key(), function(self, peer, peer_id)
		DelayedCalls:Add('DelayedModBlackListY_' .. tostring(peer_id), 1, function()
			BlackList:Record_History(peer_id)
		end)
	end)
end

if ClientNetworkSession then
	Hooks:PostHook(ClientNetworkSession, 'on_entered_lobby', 'F_'..Idstring('BlackList:ClientNetworkSessionOnEnteredLobby'):key(), function(self)
		BlackList:Record_All()
	end)

	Hooks:PostHook(ClientNetworkSession, 'on_load_complete', 'F_'..Idstring('BlackList:ClientNetworkSessionOnLoadComplete'):key(), function(self, simulation)
		BlackList:Record_All()
	end)
end