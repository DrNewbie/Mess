if managers.player and managers.player:local_player() and alive(managers.player:local_player()) then
	managers.player:__use_eat_body_bag_system()
end